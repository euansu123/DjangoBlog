---
title: DeepSeek R1 本地部署
createTime: 2025/02/05 11:57:38
permalink: /article/deepseek_deploy/
tags:
  - DeepSeek
  - Ollama
  - OpenWebUi
---

# DeepSeek R1 本地部署

安装方案：使用 `Ollama` 部署模型，`Open WebUI`提供页面交互。

## 模型部署

### Ollama 安装

Ollama 是一个开源工具，允许用户在本地计算机上轻松运行、部署和交互大型语言模型（LLMs），如 LLaMA 2、Mistral、Gemma 等。支持macOS、Linux、Windows 操作系统。

访问 `Ollama` 下载地址 `https://ollama.com/download`，选择对应操作系统的安装包。

![image-20250205132202721](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205132202721.png)

点击安装包后，依次执行安装即可。

![image-20250205134909864](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205134909864.png)

安装完成后，在终端输入 `ollama -v`，出现如下信息说明安装成功。

![image-20250205134955381](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205134955381.png)

### Ollama 运行模型交互

访问 `Ollama` 模型页面：https://ollama.com/search，搜索要安装的模型。

![image-20250205135254462](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205135254462.png)

复制页面上运行模型的命令，在终端直接执行，执行结束后出现 `success` 说明模型运行成功。

```shell
ollama run deepseek-r1:1.5b
```

![image-20250205131221219](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205131221219.png)

终端成功运行模型后，通过终端交互就可以进行提问了。

![image-20250205131926662](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205131926662.png)

## 页面交互

### Open WebUI 安装

Open WebUI是一个可扩展、功能丰富、用户友好的自托管 WebUI，旨在完全离线操作。它支持各种LLM运行程序，包括 Ollama 和 OpenAI 兼容的 API。Open WebUI 适配了 Ollama 接口，提供了 web 的方式来访问 Ollama API。

这里使用 `pip` 直接安装 `open webui`，执行如下命令。

```shell
pip install open-webui
```

使用 `pip` 成功安装后，使用如下命令执行 `open webui`。

```shell
open-webui serve
```

执行成功后，访问 `localhost:8080`，即可看到如下页面。

![image-20250205131700807](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205131700807.png)

页面上能够自动获取到 `Ollama` 运行的模型，能够正常使用模型进行相关的交互提问，如下所示。

![image-20250205131824320](/DeepSeek%20R1%20%E6%9C%AC%E5%9C%B0%E9%83%A8%E7%BD%B2/image-20250205131824320.png)