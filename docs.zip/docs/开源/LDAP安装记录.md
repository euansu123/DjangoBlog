---
title: LDAP操作记录
createTime: 2021/12/26 11:57:38
permalink: /article/ldap_tutorial/
tags:
  - LDAP
---

<meta name="referrer" content="no-referrer"/>

LDAP是一个为查询、浏览和搜索而优化的专业分布式数据库，它成树状结构组织数据，类似于Linux/Unix系统中的文件目录一样。 目录数据库和关系数据库不同，它有优异的读性能，但写性能差，并且没有事务处理、回滚等复杂功能，不适于存储修改频繁的数据。所以目录天生是用来查询的，就好像它的名字一样，目录服务是由目录数据库和一套访问协议组成的系统。

<!--more-->

#### 安装 openldap

1. yum安装相关包
   
   ```
   sudo yum install -y openldap openldap-clients openldap-servers
   ```

2. 复制默认配置到指定路径下
   
   ```
   sudo cp /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG
   ```

3. 授权给yum安装时创建的ldap用户
   
   ```
   sudo chown -R ldap /var/lib/ldap/DB_CONFIG
   ```

4. 启动ldap服务
   
   ```
   # 启动服务
   sudo systemctl start slapd
   sudo systemctl enable slapd
   # 查看运行状态
   sudo systemctl status slapd
   ```
   
   ![Snipaste_2021-12-24_18-36-44-16404831318111](/LDAP%E5%AE%89%E8%A3%85%E8%AE%B0%E5%BD%95/Snipaste_2021-12-24_18-36-44-16404831318111.png)

#### 修改 ldap 配置

1. 生成管理员密码
   
   ```
   # sudo slappasswd -s 123456
   {SSHA}HHQ/x47AaijvK8wGhmAexBNgrx+ZDbF2
   ```

2. 修改ldap的密码配置
   
   ```
   # 编辑文件如下 vim changepwd.ldif
   dn: olcDatabase={0}config,cn=config
   changetype: modify
   add: olcRootPW
   olcRootPW: {SSHA}HHQ/x47AaijvK8wGhmAexBNgrx+ZDbF2
   # 执行如下命令，将密码配置应用于ldap
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f changepwd.ldif 
   ```

3. 导入ldap基本的schema文件。
   
   ```
   # 共计12个schema文件需要导入
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/cosine.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/nis.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/inetorgperson.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/collective.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/corba.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/duaconf.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/dyngroup.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/java.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/misc.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/openldap.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/pmi.ldif
   
   sudo ldapadd -Y EXTERNAL -H ldapi:/// -f /etc/openldap/schema/ppolicy.ldif
   ```

4. 修改ldap的域名。
   
   ```
   # 修改域名 vim changedomain.ldif
   dn: olcDatabase={1}monitor,cn=config
   changetype: modify
   replace: olcAccess
   olcAccess: {0}to * by dn.base="gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth" read by dn.base="cn=admin,dc=euansu,dc=cn" read by * none
   
   dn: olcDatabase={2}hdb,cn=config
   changetype: modify
   replace: olcSuffix
   olcSuffix: dc=euansu,dc=cn
   
   dn: olcDatabase={2}hdb,cn=config
   changetype: modify
   replace: olcRootDN
   olcRootDN: cn=admin,dc=euansu,dc=cn
   
   dn: olcDatabase={2}hdb,cn=config
   changetype: modify
   replace: olcRootPW
   olcRootPW: {SSHA}HHQ/x47AaijvK8wGhmAexBNgrx+ZDbF2
   
   dn: olcDatabase={2}hdb,cn=config
   changetype: modify
   add: olcAccess
   olcAccess: {0}to attrs=userPassword,shadowLastChange by dn="cn=admin,dc=euansu,dc=cn" write by anonymous auth by self write by * none
   olcAccess: {1}to dn.base="" by * read
   olcAccess: {2}to * by dn="cn=admin,dc=euansu,dc=cn" write by * read
   
   # 执行如下命令将域名应用于ldap
   sudo ldapmodify -Y EXTERNAL -H ldapi:/// -f changedomain.ldif
   ```

5. 启用memberof功能
   
   ```
   # 编写文件 vim add-memberof.ldif
   dn: cn=module{0},cn=config
   cn: modulle{0}
   objectClass: olcModuleList
   objectclass: top
   olcModuleload: memberof.la
   olcModulePath: /usr/lib64/openldap
   
   dn: olcOverlay={0}memberof,olcDatabase={2}hdb,cn=config
   objectClass: olcConfig
   objectClass: olcMemberOf
   objectClass: olcOverlayConfig
   objectClass: top
   olcOverlay: memberof
   olcMemberOfDangling: ignore
   olcMemberOfRefInt: TRUE
   olcMemberOfGroupOC: groupOfUniqueNames
   olcMemberOfMemberAD: uniqueMember
   olcMemberOfMemberOfAD: memberOf
   
   # 编写文件 vim refint1.ldif
   dn: cn=module{0},cn=config
   add: olcmoduleload
   olcmoduleload: refint
   # 编写文件 vim refint2.ldif
   dn: olcOverlay=refint,olcDatabase={2}hdb,cn=config
   objectClass: olcConfig
   objectClass: olcOverlayConfig
   objectClass: olcRefintConfig
   objectClass: top
   olcOverlay: refint
   olcRefintAttribute: memberof uniqueMember manager owner
   # 依次执行如下命令应用配置
   sudo ldapadd -Q -Y EXTERNAL -H ldapi:/// -f add-memberof.ldif
   sudo ldapmodify -Q -Y EXTERNAL -H ldapi:/// -f refint1.ldif
   sudo ldapadd -Q -Y EXTERNAL -H ldapi:/// -f refint2.ldif
   ```

6. 新增ldap组织
   
   ```
   #编写文件 vim base.ldif
   dn: dc=euansu,dc=cn
   objectClass: top
   objectClass: dcObject
   objectClass: organization
   o: Company
   dc: euansu
   
   dn: cn=admin,dc=euansu,dc=cn
   objectClass: organizationalRole
   cn: admin
   
   dn: ou=People,dc=euansu,dc=cn
   objectClass: organizationalUnit
   ou: People
   
   dn: ou=Group,dc=euansu,dc=cn
   objectClass: organizationalRole
   cn: Group
   # 执行命令，应用配置
   sudo ldapadd -x -D cn=admin,dc=euansu,dc=cn -W -f base.ldif
   ```
   
   ![Snipaste_2021-12-24_18-36-44](/LDAP%E5%AE%89%E8%A3%85%E8%AE%B0%E5%BD%95/Snipaste_2021-12-24_18-36-44.png)

#### 安装 phpldapadmin LDAP网页服务

1. 安装phpldapadmin包。

   ```
   sudo yum install -y phpldapadmin
   # 如果没有找到安装包，执行如下操作更新yum源，重新安装
   sudo yum localinstall http://rpms.famillecollet.com/enterprise/remi-release-7.rpm
   ```

2. 修改LDAP配置文件。

   ```
   # 放开外部ip的访问 sudo vim /etc/httpd/conf.d/phpldapadmin.conf
   # 其中192.168.1.3是物理主机的ip
   Alias /phpldapadmin /usr/share/phpldapadmin/htdocs
   Alias /ldapadmin /usr/share/phpldapadmin/htdocs
   
   <Directory /usr/share/phpldapadmin/htdocs>
     <IfModule mod_authz_core.c>
       # Apache 2.4
       Require all granted
     </IfModule>
     <IfModule !mod_authz_core.c>
       # Apache 2.4
       Order Deny,Allow
       Deny from all
       Allow from 127.0.0.1
       Allow from ::1
       Allow from 192.168.1.3
     </IfModule>
   </Directory>
   
   # 修改文件，更改phpldapadmin的登录方式 sudo vim /etc/phpldapadmin/config.php
   
   # 注释398行，放开387行
   $servers->setValue('login','attr','cn');
   
   # 放开460行的注释，修改为如下
   $servers->setValue('login','anon_bind',false);
   
   # 找到519行,设置用户属性的唯一性
   $servers->setValue('unique','attrs',array('mail','uid','uidNumber','cn','sn'))
   ```

3. 重启Apache服务。

   ```
   # 重启Apache服务
   sudo systemctl start httpd  
   sudo systemctl enable httpd
   ```

4. 访问页面。

   ![image-20211224203702877](/LDAP%E5%AE%89%E8%A3%85%E8%AE%B0%E5%BD%95/image-20211224203702877.png)

   输入之前的账号：cn=admin,dc=euansu,dc=cn，进行登录。

   ![image-20211225170118347](/LDAP%E5%AE%89%E8%A3%85%E8%AE%B0%E5%BD%95/image-20211225170118347.png)
