---
title: Code-Server安装部署
createTime: 2024/06/12 11:57:38
permalink: /article/code_server/
tags:
  - Code-Server
---

# Code-Server 安装部署

## 1.环境准备

可以参考 https://coder.com/docs/code-server/install code-server的安装流程进行安装，主机环境是 `Centos7` 建议使用 `docker` 方式进行安装，可能会出现如下报错，需要升级 `GNC` 的版本，由于影响交大，这里改用 `Docker` 方式安装 `Code-Server`。

![image-20240612145351054](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240612145351054.png)

`Docker Hub` 在国内无法拉取镜像，需要按照如下方式配置代理：

```shell
# 创建目录
sudo mkdir -p /etc/docker
# 写入镜像配置
sudo tee /etc/docker/daemon.json <<-'EOF'
{
    "registry-mirrors": [
        "https://docker.m.daocloud.io",
        "https://dockerproxy.com",
        "https://docker.mirrors.ustc.edu.cn",
        "https://docker.nju.edu.cn"
    ]
}
EOF
```

完成后，重启 `Docker` 服务，使用 `docker info` 命令查询如下，`Registry Mirrors` 出现添加的代理地址：

![image-20240612145640101](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240612145640101.png)

## 2.安装部署

拉取 `code-server` 镜像。

```shell
docker pull codercom/code-server
```

准备 `code-server` 的配置文件。

```shell
# 准备配置文件
mkdir -P ~/.config/code-server
vi ~/.config/code-server/config.yaml
# 写入如下内容
bind-addr: 0.0.0.0:8080
auth: password
password: ded1ca806680a94c103eb2c8
cert: false
```

运行 `code-server` 镜像。

```shell
mkdir -p ~/.config
docker run -it --name code-server -p 8080:8080 \
  -v "$HOME/.local:/home/coder/.local" \
  -v "$HOME/.config:/home/coder/.config" \
  -v "$PWD:/home/coder/project" \
  -u "$(id -u):$(id -g)" \
  -e "DOCKER_USER=$USER" \
  codercom/code-server:latest
# 上面的命令是前台启动，实际部署时，建议转为后台
docker run -itd --name code-server -p 8080:8080 \
  -v "$HOME/.local:/home/coder/.local" \
  -v "$HOME/.config:/home/coder/.config" \
  -v "$PWD:/home/coder/project" \
  -u "$(id -u):$(id -g)" \
  -e "DOCKER_USER=$USER" \
  codercom/code-server:latest
```

![image-20240621094118154](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621094118154.png)

查看 `code-server` 镜像是否运行成功。

```
docker ps | grep code-server
```

![image-20240612150638852](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240612150638852.png)

访问主机的 `8080` 端口，确认是否能够页面访问 `code-server`。

![image-20240612151250615](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240612151250615.png)

## 3.功能测试

### 3.1 `Java` 代码在线运行。

首先是安装 `jdk` 到 `code-server` 的容器中，并配置相应的环境变量。

```shell
export JAVA_HOME=/home/coder/jdk1.8.0_202
export PATH=$JAVA_HOME/bin:$PATH
```

![image-20240621101437470](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621101437470.png)

编写 `Java` 代码，安装 `Code Runner` 插件。

![image-20240621100908799](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621100908799.png)

编写完 `Java` 代码后，发现无法运行，这里需要额外安装 `Code Runner` 插件。

![image-20240621101608600](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621101608600.png)

使用 `Code-Server` 运行代码，报错显示 `javac: not found`。

修改 ` ~/.local/share/code-server/Machine/settings.json` 文件，配置为如下内容：

```json
{
    "code-runner.runInTerminal": true
}
```

`code-runner` 使用终端执行代码，修改后效果如下：

![image-20240621103820189](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621103820189.png)

### 3.2 `Golang` 代码在线运行。

首先是在 `code-server` 容器中安装 `go` 依赖环境。

```shell
export GOLANG_HOME=/home/coder/go
export PATH=$GOLANG_HOME/bin:$PATH
```

![image-20240621104641248](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621104641248.png)

编写 `golang` 代码，使用 `vscode` 在线执行代码。

```go
package main

import "fmt"

func main() {
	fmt.Println("Hello World!")
}
```

![image-20240621104818095](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621104818095.png)

### 3.3 `Pyton` 代码在线运行。

首先是在 `code-server` 中安装 `Python` 依赖环境，并配置环境变量。

```shell
export PYTHON_HOME=/home/coder/anaconda3
export PATH=$PYTHON_HOME/bin:$PATH
```

![image-20240621110417995](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621110417995.png)

编写 `Python` 代码，使用 `vscode` 在线执行代码。

![image-20240621110501471](/%E5%9C%A8%E7%BA%BFvscode%E5%AE%89%E8%A3%85/image-20240621110501471.png)

## 4.参考资料

[1] Code-Server 安装文档 https://coder.com/docs/code-server

[2] Docker Hub 拉取镜像配置 https://www.cnblogs.com/ikuai/p/18233775

