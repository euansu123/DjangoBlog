---
title: Nginx 代理 Grafana 服务
createTime: 2025/5/13 11:57:38
permalink: /article/reverse_proxy/
tags:
  - Grafana
  - Nginx
---

# Nginx 代理 Grafana 服务

> 本文记录了 `Nginx` 代理 `Grafana` 服务的两种场景，分别是将 `Grafana`  映射到 `Nginx` 的一级路由和二级路由。

## 1.映射 Grafana 到 Nginx 的一级路由

修改 `Grafana` 的配置文件，修改如下内容：

```ini
[server]

# The public facing domain name used to access grafana from a browser
# 浏览器中访问Grafana的域名配置
domain = 8.8.8.8

# Grafana的完整访问路径
root_url = %(protocol)s://%(domain)s/

# Serve Grafana from subpath specified in `root_url` setting. By default it is set to `false` for compatibility reasons.
# 如果代理为一级路由，这里需要设置为false
serve_from_sub_path = false
```

修改完成 `Grafana` 的配置后，需要重启 `Grafana` 服务使得配置文件生效。

```shell
sudo systemctl restart grafana-server
```

修改 `Nginx` 的配置文件，增加一级路由的 `server` 块，如下所示：

```nginx
server {
    listen 38003;
    server_name localhost;

    location / {
        proxy_pass http://8.8.8.8:9090/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

添加完 `server` 块的配置后，重启 `Nginx` 服务：

```shell
nginx/sbin/nginx -s reload
```

浏览器访问 `Nginx` 代理的地址，能够正常使用 `Grafana` 的各项服务。

![image-20250513113736101](/Nginx代理Grafana服务/image-20250513113736101.png)

## 2.映射 Grafana 到 Nginx 的二级路由

### 2.1 二级路由配置

修改 `Grafana` 的配置文件，修改如下内容：

```ini
# 这里找到Server快的配置
[server]

# The public facing domain name used to access grafana from a browser
# 浏览器中访问Grafana的域名配置
domain = 8.8.8.8

# Grafana的完整访问路径
root_url = %(protocol)s://%(domain)s:%(http_port)s/grafana/

# Serve Grafana from subpath specified in `root_url` setting. By default it is set to `false` for compatibility reasons.
# 如果代理为二级路由，这里需要设置为true
serve_from_sub_path = true
```

修改完成 `Grafana` 的配置后，需要重启 `Grafana` 服务使得配置文件生效。

```shell
sudo systemctl restart grafana-server
```

修改 `Nginx` 的配置文件名，在指定的 `http` 块下增加 `grafana` 的二级子路由配置：

```nginx
server {
    listen 28002;
    server_name localhost;

    location /grafana/ {
        proxy_pass http://8.8.8.8:9090/grafana/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    ...

        error_page 404 500 502 503 504  /50x.html;

    location = /50x.html {
        root html;
    }
}
```

添加完二级子路由的配置后，重启 `Nginx` 服务：

```shell
nginx/sbin/nginx -s reload
```

浏览器访问 `Nginx` 代理的子路由，能够正常使用 `Grafana` 的各项服务。

![image-20250513112847920](/Nginx代理Grafana服务/image-20250513112847920.png)

### 2.2 问题记录

二级代理的时候有个问题，发现它总是多增加了一层 `grafana` 路由，可能会出现无法打开登录页的情况，如下图所示：

![image-20250513144839181](/Nginx代理Grafana服务/image-20250513144839181.png)

这里是因为在 `Nginx` 中配置了如下二级路由

```nginx
server {
    listen 8000;
    server_name localhost;

    location /grafana/ {
        proxy_pass http://8.8.8.8:9090/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    ...

        error_page 404 500 502 503 504  /50x.html;

    location = /50x.html {
        root html;
    }
}
```

因此，浏览器访问 `grafana/xxx`，会变成请求后端 `/xxx`，但是 `grafana` 中配置了如下内容：

```ini
root_url = .../grafana/
serve_from_sub_path = true
```

于是在返回的所有路径前都自动添加了 `/grafana`，因此导致页面上访问的路由多添加了一层 `grafana` 地址，修改 `nginx` 的代理配置为如下内容即可解决该问题：

```nginx
server {
    listen 8000;
    server_name localhost;

    location /grafana/ {
        proxy_pass http://8.8.8.8:9090/grafana/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    ...

        error_page 404 500 502 503 504  /50x.html;

    location = /50x.html {
        root html;
    }
}
```

