---
title: 基于 Apache 的 httpd 文件服务器
createTime: 2024/07/20 11:57:38
permalink: /article/apache_httpd/
tags:
  - Apache
  - httpd
---



# 基于 `Apache` 的 `httpd` 文件服务器

## 文件服务器的简介

`httpd（HTTP Daemon，超文本传输协议守护进程的简称）`，运行于网页服务器后台，等待传入服务器请求的软件。

`httpd` 能够自动回应服务器的请求，并使用 `http` 协议传送超文本及多媒体内容。

常见的 `httpd` 以下实现：

- `Apache HTTP Server`
- `CERN HTTPd` 
- `Cherokee`
- `Hiawatha`
- `Lighttpd`
- `NCSA HTTPd`
- `Nginx`
- `OpenBSD`

这里我们使用应用最广泛的 `Apache Http Server` 搭建 `httpd` 文件服务器。

## 文件服务器的搭建

所使用的服务器操作系统是 `CentOS 7.9`，使用 `yum` 命令直接安装 `httpd`，如 `yum` 源有问题或者非 `CentOS` 操作系统，需要先准备软件源以及安装命令，`CentOS` 的主机执行如下命令即可安装 `httpd` 服务。

```shell
sudo yum install httpd
```

安装完成后，需要修改 `/etc/httpd/conf/httpd.conf` 配置文件，重点修改的内容如下所示。

```ini
# httpd服务端口
Listen 8000

# httpd服务用户
User apache
Group apache

# httpd服务根目录
DocumentRoot "/www/httpd"

# httpd服务根路径的权限
<Directory "/www/httpd">
	# 展示文件列表以及软链接的内容
    Options Indexes FollowSymLinks
    # 不允许使用.htaccess文件来修改Apache的配置。
    AllowOverride None
    # 允许所有用户访问此目录中的内容，也即，对所有请求都允许访问该目录及其内容。
    Require all granted
</Directory>
```

配置修改完成后，还需要修改 `/www/httpd` 也即配置的 `httpd` 文件服务器的目录属主，这里直接修改为 `apache:apache`。

```shell
chown -R apache:apache /www/httpd
```

![image-20240721002631792](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721002631792.png)

使用 `systemctl start httpd` 即可启动 `Apache Httpd` 文件服务器，如下是常用的 `httpd` 命令。

```shell
# 启动 httpd 服务
systemctl start httpd
# 重启 httpd 服务
systemctl restart httpd
# 停止 httpd 服务
systemctl stop httpd
# 查看 httpd 服务状态
systemctl status httpd
```

![image-20240721001819287](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721001819287.png)

`Httpd` 服务启动后，即可通过页面访问文件服务器的 `web` 页面。

![image-20240721002110845](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721002110845.png)

`Apache httpd` 默认是 `Apache http server` 的页面，这里可以直接删除 `/etc/httpd/conf.d/welcome.conf`  这个文件移除这个页面，也可以修改这个文件修改默认展示的页面，这里我们直接删除配置文件，并重启 `Apache httpd` 服务，出现的页面如下。

![image-20240721002453957](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721002453957.png)

## 文件服务器的使用

访问默认的页面，出现的内容为空，这是因为配置的文件服务器根目录下没有内容，这里我们在配置的文件服务器根目录下创建 `nginx` 目录，并传入 `nginx` 的安装包。

```shell
mkdir /www/httpd/nginx
mv nginx-1.24.0.tar.gz /www/httpd/nginx
# 这里要注意允许其他用户访问当前目录，否则会出现无权限的问题
chown -R 755 /www/httpd/nginx
```

访问文件服务的页面，就能够看到创建的 `nginx` 目录以及安装包。

![image-20240721003209383](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721003209383.png)



![image-20240721003250956](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721003250956.png)

点击页面上的文件名称，或者在服务器上使用 `wget`，即可下载对应的文件。

![image-20240721003411673](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721003411673.png)

![image-20240721004348638](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721004348638.png)

如上已经实现了文件服务器，但在浏览器中下载文件时，会提醒这是不安全的，这里使用 `nginx` 代理文件服务器并配置 `ssl` 证书即可避免这种问题。

![image-20240721004545368](/httpd%E6%96%87%E4%BB%B6%E6%9C%8D%E5%8A%A1%E5%99%A8/image-20240721004545368.png) 
