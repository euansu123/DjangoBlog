---
title: 构建本地yum镜像源
createTime: 2025/04/19 00:03:59
permalink: /article/041tlmd3/
tags:
  - yum
---
# 构建本地yum镜像源

## 0.前提条件

- 需要预先准备操作系统对应架构的 `ISO` 文件，这里选择 `Centos` 的`arm` 镜像文件：`CentOS-7-aarch64-Minimal.iso`。
- 对应架构的操作主机，系统最好保持一致，这里使用 `openEuler` 构建 `Centos` 的镜像源无报错。
- 安装工具：`createrepo`、`Apache httpd`，需要提前安装好。

## 1.操作步骤

### 1.1 安装工具

```shell
sudo yum install -y createrepo httpd
```

![image-20250418233553704](/构建本地yum镜像源/image-20250418233553704.png)

### 1.2 挂载 ISO 文件

```shell
sudo mkdir -p /mnt/centos7-arm-iso
sudo mount -o loop ${iso文件的所在目录} /mnt/centos7-arm-iso
```

![image-20250418233853497](/构建本地yum镜像源/image-20250418233853497.png)

### 1.3 拷贝文件到本地仓库目录

```shell
sudo mkdir -p /opt/yum-repo/centos7-arm
sudo cp -av /mnt/centos7-arm-iso/* /opt/yum-repo/centos7-arm/
sudo umount /mnt/centos7-arm-iso
```

按照如上步骤操作完成后，能够在本地目录查看到拷贝的文件信息。

![image-20250418234003564](/构建本地yum镜像源/image-20250418234003564.png)

### 1.4 创建yum仓库元数据（可选）

如 `1.3` 图中所示已经包含 `repodata` 目录，一般无需进行 `yum` 仓库元数据的操作，以防万一也可以执行如下命令重新生成：

```shell
sudo createrepo /opt/yum-repo/centos7-arm/
```

### 1.5 配置HTTP服务

使用如下命令启动 `Apache Httpd` 服务

```shell
sudo systemctl enable httpd
sudo systemctl start httpd
```

`Apache httpd` 服务默认为 `80` 端口，浏览器中输入主机的 `IP` 即可查看到 `Apache Httpd` 的页面，如下所示

![image-20250418234414862](/构建本地yum镜像源/image-20250418234414862.png)

将本地仓库目录暴露给 `Apache Httpd` 服务，如下所示：

```shell
# Apache Httpd服务默认目录为/var/www/html，如果有变动需要以实际配置的目录为准
sudo ln -s /opt/yum-repo/centos7-arm /var/www/html/centos7-arm
```

在浏览器中，添加 `/centos7-arm` 路由即可查看到配置的 `yum` 镜像源，如下所示

![image-20250418234710172](/构建本地yum镜像源/image-20250418234710172.png)

### 1.6 客户端修改yum源配置

编辑或者创建 `/etc/yum.repos.d/local-arm.repo`

```shell
[local-arm]
name=Local CentOS 7 ARM Repo
baseurl=http://10.86.25.22/centos7-arm/
enabled=1
gpgcheck=0
```

这里启用一个`centos`的`Docker`镜像，修改镜像的 `yum` 源配置，如下所示：

![image-20250418235041360](/构建本地yum镜像源/image-20250418235041360.png)

## 2.本地yum源测试

```shell
yum clean all
yum repolist
```

这里能够正常操作，但配置的 `yum` 镜像仓库中存在阿里云的镜像。

![image-20250418235206146](/构建本地yum镜像源/image-20250418235206146.png)

移除掉阿里云的镜像仓库配置，再次执行测试，就只存在新搭建的本地镜像源。

![image-20250418235621095](/构建本地yum镜像源/image-20250418235621095.png)

尝试安装 `yum` 包，能够正常进行操作。

```shell
yum install zip
```

![image-20250418235748740](/构建本地yum镜像源/image-20250418235748740.png)

## 3.镜像仓库下载地址

- https://mirrors.huaweicloud.com/centos-altarch/7/isos/aarch64/CentOS-7-aarch64-Minimal-2009.iso（华为云，最小镜像）
- https://mirrors.huaweicloud.com/centos-altarch/7/isos/aarch64/CentOS-7-aarch64-Everything-2009.iso（华为云，完整镜像）



