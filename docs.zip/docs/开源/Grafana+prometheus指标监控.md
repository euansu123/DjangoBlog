---
title: Prometheus + Grafana指标监控
createTime: 2023/07/11 11:57:38
permalink: /article/prometheus_and_grafana/
tags:
  - Prometheus
  - Grafana
---

Prometheus 对大数据组件HDFS的指标进行采集，Grafana进行可视化展示。

<!--more-->

# 1.Prometheus

1. 下载 `Prometheus` 安装包。

   ```shell
   wget https://github.com/prometheus/prometheus/releases/download/v2.45.0/prometheus-2.45.0.linux-amd64.tar.gz
   # 页面下载地址
   https://prometheus.io/download/
   ```

   ![image-20230707160343588](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707160343588.png)

2. 上传 `Prometheus` 到规划的路径并进行解压。

   ```shell
   tar -zxvf prometheus-2.37.8.linux-amd64.tar.gz
   ```

3. 启动 `Prometheus` 服务。

   ```shell
   # 需要在 Prometheus 目录下执行如下操作
   ./prometheus --config.file=prometheus.yml
   # 建议后台启动，命令如下
   nohup ./prometheus --config.file=prometheus.yml >> prometheus.log 2>&1 &
   ```

   启动后，即可在页面访问 `Prometheus` 服务。

   ![image-20230707160714058](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707160714058.png)

# 2.Grafana

1. 下载 `Grafana` 安装包。

   ```sh
   # 这里下载的是安装包，注意不要下载源码包
   wget https://dl.grafana.com/enterprise/release/grafana-enterprise-9.5.2.linux-amd64.tar.gz
   # 页面下载地址
   https://grafana.com/grafana/download/10.0.0?pg=oss-graf&plcmt=hero-btn-1
   ```

   ![image-20230707160102548](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707160102548.png)

2. 上传到主机规划的目录并进行解压。

   ```shell
   tar -zxvf grafana-enterprise-9.5.2.linux-amd64.tar.gz
   ```

3. 启动 `Grafana` 服务。

   ```shell
   # 需要在 Grafana 目录下执行如下操作
   ./bin/grafana-server web
   # 建议后台启动，命令如下
   nohup ./grafana-server web 2>&1 >> /e3base/apps/grafana/logs/grafana.log &
   ```

   启动后，即可在页面访问 `Grafana` 服务。

   ![image-20230707160215621](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707160215621.png)

# 3.指标监控

## 3.1 HDFS

### 3.1.1 NameNode

**环境信息**

```shell
# jmx端口
12003
# NameNode节点
host-172-18-243-34
host-172-18-243-35
# 环境
Kerberos
```

**jmx 接口测试**

```shell
curl -X GET --negotiate -u e3base:e3base -i http://host-172-18-243-34:12003/jmx
curl -X GET --negotiate -u e3base:e3base -i http://host-172-18-243-35:12003/jmx
```

![image-20230707161034088](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707161034088.png)

**Kerberos代理**

`Prometheus` 只能够采集非 `Kerberos` 环境的信息，`Kerberos` 环境下需要使用如下方法，将 `Kerbeors` 页面代理成非 `Kerberos` 页面供 `Prometheus` 进行数据采集。

1. 解压附件中的 `http_exporter.zip` 文件。
   ```shell
   unzip http_exporter.zip
   ```

2. 修改 `httpjmx.yml` 配置文件，设置代理信息。 

   ```yaml
   httpTimeout: 10
   httpUrl:
     - "namenode|http://host-172-18-243-34:12003/jmx"
   blacklistObjectNames:
     - "Hadoop:service=NameNode,name=NameNodeInfo|LiveNodes|DeadNodes"
     - "Hadoop:service=NameNode,name=FSNamesystemState|TopUserOpCounts"
     - "Hadoop:service=DataNode,name=DataNodeInfo|DatanodeNetworkCounts"
   wightlistObjectNames:
     - "not use now"
   valueReplace:
     - "true:1"
     - "false:0"
     - "active:1"
     - "standby:0"
   krbSwitch: 1
   krbPrincipal: "e3base@SITECH.COM"
   krbKeyTab: "/etc/security/keytabs/e3base.keytab"
   krbUseTicketCache: "true"
   krbRenewTGT: "true"
   krbRefreshKrb5Config: "true"
   krbStoreKey: "false"
   krbIsInitiator: "true"
   krbDebug: "true"
   debug: 0
   ```

3. 启动 `http_exporter` 代理服务。

   ```shell
   nohup /e3base/jdk/bin/java -cp collector-0.16.2-SNAPSHOT.jar io.prometheus.jmx.httpjmx.HadoopCollector 172.18.243.36:9102 httpjmx.yml 2>&1 &
   ```

4. 配置 `Prometheus` 的配置文件。

   ```yaml
   scrape_configs:
     # The job name is added as a label `job=<job_name>` to any timeseries scraped from this config.
     - job_name: "prometheus"
   
       # metrics_path defaults to '/metrics'
       # scheme defaults to 'http'.
   
       static_configs:
         - targets: ["localhost:9090"]
   
     - job_name: "namenode"
   
       static_configs:
         - targets: ["172.18.243.36:9102","172.18.243.36:9103"]
   ```

5. 重启 `Prometheus` 服务，页面上出现 `namenode` 的相关数据。

   ![image-20230707161718597](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707161718597.png)

6. 导入附件中的 `namenode.json` 到 `Grafana`，注意修改文件中的 `datasource` 参数，设置成 `Promnetheus` 的 `target` 名称。

   ![image-20230707162003538](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707162003538.png)

7. 导入后，页面数据正常展示。

   ![image-20230707162132401](/Grafana+prometheus%E6%8C%87%E6%A0%87%E7%9B%91%E6%8E%A7/image-20230707162132401.png)

