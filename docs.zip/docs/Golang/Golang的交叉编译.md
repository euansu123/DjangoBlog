---
title: Golang的交叉编译
createTime: 2024/09/02 11:57:38
permalink: /article/golang_build/
tags:
  - Golang
---

# `Golang` 的交叉编译

交叉编译也即编译输出不同系统和架构下的 `Golang` 可执行文件，过程中需要修改三个变量即可，分别是：

- `GOOS`：可执行程序运行的操作系统（`Linux`、`Windows`)
- `GOARCH`：可执行程序所在设备的 `CPU` 架构（`x86`、`arm`等）
- `CGO_ENABLED`：交叉编译，如果编译输出的可执行文件无法在当前系统执行，需要设置为 `0`。

## 1.编译 `x86` 架构上的 `windows` 可执行文件

```shell
$env:GOOS="windows"
$env:GOARCH="amd64"
$CGO_ENABLED=1
go build -o .\windows\hbaseCollectContact.exe
```

![image-20240902182327152](/Golang%E7%9A%84%E4%BA%A4%E5%8F%89%E7%BC%96%E8%AF%91/image-20240902182327152.png)

## 2.编译 `x86` 架构上的 `linux` 可执行文件

```shell
$env:GOOS="linux"
$env:GOARCH="amd64"
$CGO_ENABLED=0
go build -o .\x86\hbaseCollectContact
```

![image-20240902182532636](/Golang%E7%9A%84%E4%BA%A4%E5%8F%89%E7%BC%96%E8%AF%91/image-20240902182532636.png)

上传到主机上进行测试，能够正常运行。

![image-20240902182850562](/Golang%E7%9A%84%E4%BA%A4%E5%8F%89%E7%BC%96%E8%AF%91/image-20240902182850562.png)

## 3.编译 `arm` 架构上的 `linux` 可执行文件

```shell
$env:GOOS="linux"
$env:GOARCH="arm64"
$CGO_ENABLED=0
go build -o .\arm64\hbaseCollectContact
```

![image-20240902183021338](/Golang%E7%9A%84%E4%BA%A4%E5%8F%89%E7%BC%96%E8%AF%91/image-20240902183021338.png)

上传到主机上进行测试，能够正常运行。

![image-20240902183204818](/Golang%E7%9A%84%E4%BA%A4%E5%8F%89%E7%BC%96%E8%AF%91/image-20240902183204818.png)
