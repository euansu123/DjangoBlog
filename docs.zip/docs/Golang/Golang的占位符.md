---
title: Go语言中占位符
createTime: 2024/07/08 11:57:38
permalink: /article/golang_placeholder/
tags:
  - Golang
---

# Golang的占位符

`Golang` 的字符串占位符在 `fmt` 包的各种打印函数中使用，如 `fmt.Printf`、`fmt.Sprintf`。



## 变量值与类型的打印

**`%v`**: 打印变量的值

- `%v` 会根据变量的类型选择合适的格式进行打印。
- 对于结构体，`%v` 会打印出结构体的字段。
- 对于指针类型，会打印出指针指向的值。

**`%T`**: 打印变量的类型

- `%T` 会打印出变量的具体类型。

```go
x := 42
y := "hello"
z := 3.14
fmt.Printf("x: %v, 类型: %T\n", x, x)
fmt.Printf("y: %v, 类型: %T\n", y, y)
fmt.Printf("z: %v, 类型: %T\n", z, z)
```

运行如上代码，输出

```shell
x: 42, 类型: int
y: hello, 类型: string
z: 3.14, 类型: float64
```

## 整数

`%d` 十进制表示
`%b` 二进制表示
`%o` 八进制表示
`%x`、`%X` 十六进制表示（`%x` 小写字母、`%X` 大写字母）

```go
n := 42
fmt.Printf("十进制: %d\n", n)
fmt.Printf("二进制: %b\n", n)
fmt.Printf("八进制: %o\n", n)
fmt.Printf("十六进制（小写）: %x\n", n)
fmt.Printf("十六进制（大写）: %X\n", n)
```

运行如上代码，输出

```shell
十进制: 42
二进制: 101010
八进制: 52
十六进制（小写）: 2a
十六进制（大写）: 2A
```

## 浮点数和整数

`%f` 有小数点的十进制表示
`%e`、`%E` 科学计数法
`%g`,` %G`: 根据情况选择 `%f` 或 `%e` (`%g` 使用小写字母，`%G` 使用大写字母)

```go
f := 3.1415926
fmt.Printf("浮点数: %f\n", f)
fmt.Printf("科学计数法（小写）: %e\n", f)
fmt.Printf("科学计数法（大写）: %E\n", f)
```

运行如上代码，输出

```shell
浮点数: 3.141593
科学计数法（小写）: 3.141593e+00
科学计数法（大写）: 3.141593E+00
```

## 字符串和字节切片

`%s`: 直接输出字符串或字节切片
`%q`: 使用双引号括起来的字符串
`%x`, `%X`: 每个字节用两字符的十六进制表示

```go
s := "hello"
fmt.Printf("字符串: %s\n", s)
fmt.Printf("带引号的字符串: %q\n", s)
fmt.Printf("每个字节用十六进制表示（小写）: %x\n", s)
fmt.Printf("每个字节用十六进制表示（大写）: %X\n", s)
```

运行如上代码，输出

```shell
字符串: hello
带引号的字符串: "hello"
每个字节用十六进制表示（小写）: 68656c6c6f
每个字节用十六进制表示（大写）: 68656C6C6F
```

## 指针

 `%p`: 指针地址

```go
t := 100
p := &t
fmt.Printf("指针地址: %p\n", p)
```

运行如上代码，输出

```shell
指针地址: 0xc00001a128
```

## 布尔值

`%t`: 布尔值（`true` 或 `false`）

```go
b := true
fmt.Printf("布尔值： %t\n", b)
```

运行如上代码，输出

```shell
布尔值： true
```

## 其他

`%%`: 字面上的百分号（`%`）
`%U`: `Unicode` 格式：`U+1234`
`%c`: 字符（对应 `Unicode` 码点）
`%v`, `%+v`, `%#v`: 通用的占位符
    `%v`: 值的默认格式表示
    `%+v`: 类似 `%v`，但会打印结构体的字段名
    `%#v`: 值的 `Go` 语言语法表示

```go
fmt.Printf("百分号: 100%%\n")

// 定义如下 Unicode 字符
var char1 rune = 'A'
var char2 rune = '中'
var char3 rune = '😊'

// 使用 %U 格式化输出 Unicode 码点
fmt.Printf("char1: %c Unicode: %U\n", char1, char1)
fmt.Printf("char2: %c Unicode: %U\n", char2, char2)
fmt.Printf("char3: %c Unicode: %U\n", char3, char3)

type Person struct {
    Name string
    Age  int
}

person := Person{
    Name: "Alice",
    Age:  30,
}

fmt.Printf("值的默认格式表示: %v\n", person)
fmt.Printf("值带结构体的字段名表示: %+v\n", person)
fmt.Printf("值的Go语言语法表示: %#v\n", person)
```

运行如上代码，输出

```shell
百分号: 100%
char1: A Unicode: U+0041
char2: 中 Unicode: U+4E2D
char3: 😊 Unicode: U+1F60A
值的默认格式表示: {Alice 30}
值带结构体的字段名表示: {Name:Alice Age:30}
值的Go语言语法表示: main.Person{Name:"Alice", Age:30}
```

