---
title: Mysql源码编译安装
createTime: 2022/08/07 10:57:38
permalink: /article/mysql_source_code_compile/
tags:
  - MySQL
---

 Mysql编译安装能够根据需要设定参数，按照需求进行定制安装，并且安装的版本可以根据项目需要灵活选择，整体可配置弹性大。

<!--more-->

# 前提准备

## 下载 mysql 源码包

到 https://downloads.mysql.com/archives/community/ 下载对应版本的安装包，需要注意的是 mysql5.7 编译安装需要boost 库，可以在官网下载含 boost 的源码包。

![image-20220807153737914](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807153737914-16598580753021.png)

## 安装相关依赖包

```shell
sudo yum install -y gcc gcc-c++ cmake ncurses ncurses-devel bison wget openssl-devel.x86_64
```

![image-20220807151805742](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807151805742.png)

## 创建 mysql 所需目录

```shell
mkdir /iddbs/mysql
mkdir /iddbdata/3306/data
mkdir /iddbdata/3306/binlog/
mkdir /iddbdata/3306/logs/
```

# 编译安装

## 配置相关参数

```shell
cmake -DCMAKE_INSTALL_PREFIX=/iddbs/mysql  -DMYSQL_DATADIR=/iddbdata/3306/data -DMYSQL_UNIX_ADDR=/iddbdata/3306/mysql.sock -DDEFAULT_CHARSET=utf8 -DDEFAULT_COLLATION=utf8_general_ci -DWITH_BOOST=boost
# DCMAKE_INSTALL_PREFIX  指定MySQL程序的安装目录
# DMYSQL_DATADIR         数据文件目录
# DMYSQL_UNIX_ADDR       socket文件路径
# DDEFAULT_CHARSET       指定服务器默认字符集，默认latin1
# DDEFAULT_COLLATION     指定服务器默认的校对规则，默认latin1_general_ci
```

![image-20220807152228029](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807152228029.png)

## 源码编译安装

```shell
make & make install
```

![image-20220807160836849](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807160836849.png)

## 准备 mysql 配置文件

```shell
# 准备my.cnf文件
[client]
port=3305
socket=/iddbdata/3306/mysql.sock

[mysqld]
port=3306
server-id=1013306
basedir=/iddbs/mysql
plugin-dir=/iddbs/mysql/lib/plugin
datadir=/iddbdata/3306/data
log-bin=/iddbdata/3306/binlog/bin-log
pid-file=/iddbdata/3306/mysql.pid
socket=/iddbdata/3306/mysql.sock
relay-log=/iddbdata/3306/binlog/relay-log
log-error=/iddbdata/3306/logs/mysql-error.log
log_timestamps=system
```

## 初始化 mysql

```shell
# 如果不加--initialize-insecure，会直接在前台输出密码
/iddbs/mysql/bin/mysqld --defaults-file=/iddbdata/3306/my.cnf --user=euansu --initialize-insecure
```

![image-20220807161436617](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807161436617.png)

## 启动 mysql

```shell
/iddbs/mysql/bin/mysqld_safe --defaults-file=/iddbdata/3306/my.cnf --user=euansu &
```

![image-20220807161351328](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807161351328.png)

## 连接 mysql

```shell
/iddbs/mysql/bin/mysql -uroot -S /iddbdata/3306/mysql.sock
```

设置 root 账户密码。

```
set password for root@localhost = password("mysql");
```

![image-20220807161521346](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807161521346.png)

# mysql 相关操作

```sql
# 设置mysql密码
set password for root@localhost = password("mysql");

# 创建数据库
create database idbcdb;

# 创建mysql用户
create user 'euansu'@'%' identified by 'euansu';

# 刷新权限
flush privileges;

# 用户赋予mysql远程操作的所有权限
grant all privileges on *.* to euansu@'%';

# 查看用户euansu的权限域
show grants for euansu@'%';
```

![image-20220807161832090](/mysql%E6%BA%90%E7%A0%81%E7%BC%96%E8%AF%91%E5%AE%89%E8%A3%85/image-20220807161832090.png)





