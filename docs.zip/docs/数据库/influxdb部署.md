---
title: InfluxDB 部署使用
createTime: 2024/04/26 11:57:38
permalink: /article/influxdb_deploy/
tags:
  - influxDB
---

# InfluxDB部署测试

## 1.InfluxDB说明

### 1.1InfluxDB介绍

​		InfluxDB是一个时间序列数据库，旨在处理高性能的写入和查询。InfluxDB旨在用作涉及大量带时间戳的时序数据的存储，包括监控，应用程序指标，物联网传感器数据，同时也包含实时分析。

​		InfluxDB是一个针对时间序列数据进行了优化的数据库。此数据通常来自分布式传感器组，来自大型网站的点击数据或金融交易列表等。

​		InfluxDB不是一个完整的CRUD数据库，而是更像CR-ud，牺牲了删除和更新的操作换取到更高的读写性能。

​		与其他数据库不同，时序数据库包括：时间戳数据存储和压缩，数据生命周期管理，数据汇总，处理许多记录的大量时间序列相关扫描的能力以及时间序列的查询。

### 1.2 InfluxDB版本说明

```shell
# influxdb版本
v1.7.11
# influxdb官方网站
https://www.influxdata.com/products/influxdb/
# influxdb安装包
## x86
https://dl.influxdata.com/influxdb/releases/influxdb-1.7.11_linux_amd64.tar.gz
## arm
https://dl.influxdata.com/influxdb/releases/influxdb-1.7.11_linux_arm64.tar.gz
```

## 2.InfluxDB部署

### 2.1 部署规划

1. 用户规划

   | 用户   | 用户组 | 用户家目录 |
   | ------ | ------ | ---------- |
   | euansu | euansu | /euansu    |

2. 目录规划

   | 路径                  | 路径说明                 |
   | --------------------- | ------------------------ |
   | /euansu/influxdb      | influxdb根路径           |
   | /euansu/influxdb/meta | influxdb元数据目录       |
   | /euansu/influxdb/data | influxdb数据目录         |
   | /euansu/influxdb/wal  | influxdb wal日志预写目录 |
   | /euansu/influxdb/log  | influxdb日志目录         |

3. 端口规划

   | 端口 | 端口说明                                           |
   | ---- | -------------------------------------------------- |
   | 8080 | influxdb的http端口，非特殊情况禁止使用原生端口8086 |

### 2.2 部署操作

1. 解压 `influxDB` 安装包，并设置软连接。

   ```shell
   tar -zxvf influxdb-1.7.11_linux_arm64.tar.gz
   ln -s influxdb-1.7.11-1 influxdb
   ```

2. 修改环境变量。

   ```shell
   # vi ~/.bash_profile
   # 新增如下环境变量
   export INFLUXDB_HOME=/euansu/influxdb
   export PATH=$PATH:$INFLUXDB_HOME/usr/bin
   export INFLUXDB_CONFIG_PATH=/euansu/influxdb/etc/influxdb/influxdb.conf
   # 环境变量配置完成后，执行 source  ~/.bash_profile 刷新环境变量
   ```

3. 修改 `influxDB` 配置文件。

   ```ini
   # vi $INFLUXDB_HOME/etc/influxdb/influxdb.conf
   [meta]
       dir = "/euansu/influxdb/meta"
       #数据库元数据存储目录
       retention-autocreate = true
       #控制默认存储策略，数据库创建时，会自动生成autogen的存储策略，默认是true
       logging-enabled = true
       #是否开启meta日志，默认是true
   [data]
       dir = "/euansu/influxdb/data"
       #时序数据存放目录
       wal-dir = "/euansu/influxdb/wal"
       #wal预写日志目录
       query-log-enabled = true
       #是否开启tsm引擎查询日志，默认值： true
       cache-max-memory-size = "1g"
       #用于限定shard最大值，大于该值时会拒绝写入，默认值：1G
       cache-snapshot-memory-size = "25m"
       #设置快照大小，大于该值时数据会刷新到tsm文件，默认值：25M
       cache-snapshot-write-cold-duration = "10m"
       # tsm1引擎 snapshot写盘延迟，默认值：10min
       max-series-per-database = 1000000
       #限制数据库的级数，该值为0时取消限制，默认值：1000000
       ax-values-per-tag = 100000
       #一个tag最大的value数，0取消限制，默认值：100000
   [coordinator]
       write-timeout = "10s"
       #写操作超时时间，默认值： 10s
       max-concurrent-queries = 0
       #最大并发查询数，0无限制，默认值：0
       query-timeout = "0s"
       #查询操作超时时间，0无限制，默认值：0s
       log-queries-after = "0s"
       #慢查询超时时间，0无限制，默认值：0s
       max-select-point = 0
       # select语句可以处理的最大点数（points），0无限制，默认值：0
       max-select-series = 0
       # select语句可以处理的最大级数（series），0无限制，默认值：0
       max-select-buckets = 0
       # select语句可以处理的最大"GROUP BY time()"的时间周期，0无限制，默认值：0
   [retention]
       enabled = true
       #是否启用数据保留策略模块，默认值：true
       check-interval = "30m"
       #检查时间间隔，默认值 ："30m0s"
   [shard-precreation]
       enabled = true
       #是否启用分区预创建模块，默认值：true
       check-interval = "10m"
       #检查时间间隔，默认值 ："10m0s"
       advance-period = "30m"
       #预创建分区的最大提前时间，默认值 ："30m0s"
   [monitor]
       store-enabled = true
       #是否启用该模块，默认值 ：true。控制InfluxDB自有的监控系统。 默认情况下，InfluxDB把这些数
       据写入_internal 数据库
       store-database = "_internal"
       #默认数据库："_internal"
       store-interval = "10s"
       #统计间隔，默认值："10s"
   [http]
       enabled = true
       #是否启用http接口配置。默认值：true
       bind-address = "127.0.0.1:8080"
       #绑定http地址，绑定地址，默认值：":8086"
       auth-enabled = false
       #是否开启认证，默认值：false
       log-enabled = true
       #是否开启日志，默认值：true
       max-row-limit = 0
       #配置查询返回最大行数，0无限制，默认值：0
       max-connection-limit = 0
       #配置最大连接数，0无限制，默认值：0
   ```

4. 创建所需要的目录。

   ```shell
   mkdir -p /euansu/influxdb/meta
   mkdir -p /euansu/influxdb/data
   mkdir -p /euansu/influxdb/wal
   mkdir -p /euansu/influxdb/logs
   ```

### 2.3 InfluxDB 服务启停

```shell
#启动InfluxDB服务
nohup /euansu/influxdb/usr/bin/influxd 2>&1 >> /euansu/influxdb/logs/influxdb.log &
#停止InfluxDB服务
#找到influxdb的服务进程的pid
ps -ef | grep influxd
kill -9 pid
```

![image-20241007155513369](/influxdb部署/image-20241007155513369.png)

### 2.4 InlfuxDB 用户配置

1. 连接 `influxDB` 数据库，创建用户。

   ```shell
   # 连接influxdb
   influx -host 127.0.0.1 -port 8080
   # 创建用户
   CREATE USER root WITH PASSWORD 'root@123'
   # 创建管理员用户
   CREATE USER admin WITH PASSWORD 'root@123' WITH ALL PRIVILEGES
   ```

   ![image-20241007160642038](/influxdb部署/image-20241007160642038.png)

2. 修改 `influxDB` 配置文件。

   ```ini
   # vi $INFLUXDB_HOME/etc/influxdb/influxdb.conf
   [http]
       auth-enabled = true
       #是否开启认证，默认值：false
   ```

3. 重启 `influxDB` 数据库。

   ```shell
   #启动InfluxDB服务
   nohup influxd 2>&1 >> /euansu/influxdb/logs/influxdb.log &
   #停止InfluxDB服务
   #找到influxdb的服务进程的pid
   ps -ef | grep influxd
   kill -9 pid
   #启动InfluxDB服务
   nohup influxd 2>&1 >> /euansu/influxdb/logs/influxdb.log &
   ```

4. 使用新建用户连接 `influxDB` 数据库。

   ```shell
   influx -host 127.0.0.1 -port 8080 -username admin -password 'root@123'
   ```

   ![image-20241007161003368](/influxdb部署/image-20241007161003368.png)

## 3.验证测试

### 3.1 验证

```shell
# 进程验证
ps -ef | grep influxd
# 日志验证
tail -f $ES_INFO_HOME/influxdb/logs/influxdb.log
#无报错正常
```

### 3.2 测试

#### 3.2.1 客户端测试

```sql
# 创建数据库dbcs
create database dbcs
# 查看数据库
show databases
```

![image-20241007161052506](/influxdb部署/image-20241007161052506.png)

```sql
# 使用数据库dbcs
use dbcs
# 插入数据，influxdb不需要专门创建表
INSERT cpu,hostname=euansu_host rate=0.75
# 查看数据
SELECT "hostname", "rate" FROM "cpu"
```

![image-20241007161525374](/influxdb部署/image-20241007161525374.png)



