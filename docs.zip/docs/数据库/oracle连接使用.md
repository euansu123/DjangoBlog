---
title: Oracle 19c 安装使用记录
createTime: 2022/07/15 10:57:38
permalink: /article/oracle_19c_operate/
tags:
  - Oracle
---

Oracle 数据库安装及连接操作。

<!--more-->

# 准备工作

1. 下载 Oracle 19c 安装包，下载地址：https://www.oracle.com/database/technologies/oracle-database-software-downloads.html#19c
   
   ![image-20220715161021810](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220715161021810.png)

2. 下载 Oracle 19c 预安装包，下载地址：http://yum.oracle.com/repo/OracleLinux/OL7/latest/x86_64/getPackage/oracle-database-preinstall-19c-1.0-1.el7.x86_64.rpm

# 安装过程

1. 上传 rpm 包到服务器。
   
   ![image-20220715162205506](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220715162205506.png)

2. 安装 Oracle 预安装rpm包。
   
   ```shell
   yum -y localinstall oracle-database-preinstall-19c-1.0-1.el7.x86_64.rpm
   ```

3. 安装 Oracle 安装rpm包。
   
   ```shell
   yum -y localinstall oracle-database-ee-19c-1.0-1.x86_64.rpm
   ```

4. 配置 Oracle 环境。
   
   ```shell
   /etc/init.d/oracledb_ORCLCDB-19c configure
   ```
   
   ![配置环境](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/%E9%85%8D%E7%BD%AE%E7%8E%AF%E5%A2%83.png)
   
   配置过程执行结束后，查询 Oracle 进程，Oracle 进程存在表示安装完成。
   
   ![image-20220715162846458](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220715162846458.png)

5. 创建 Oracle 用户，并配置 Orace 用户的环境变量。
   
   ![image-20220715163350129](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220715163350129.png)

6. 执行 sqlplus / as sysdba 校验 Oracle 数据库是否启动成功。
   
   ![image-20220715163431437](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220715163431437.png)

7. 使用连接工具测试连接是否成功。
   
   ![Snipaste_2022-07-15_16-31-58](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/Snipaste_2022-07-15_16-31-58.png)

# Oracle 数据库启停操作

```shell
/etc/init.d/oracledb_ORCLCDB-19c start|stop|restart|configure|delete
```

# Oracle 数据库简单操作

创建表空间

```sql
create tablespace tab_name
datafile 'path'
size n
[autoextend on next n1 maxsize m /of]
[permanent] 
[extent management local/dictionary];

# tab_name    表空间的名字
# path        数据文件路径
# size n    指定数据文件的大小
create tablespace euansu datafile '/home/oracle/data' size 100M;
```

![image-20220714191811220](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714191811220.png)

![image-20220714191826269](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714191826269.png)

创建临时表空间

```sql
create temporary tablespace temp_name tempfile 'path' size n;

# tempname    表空间的名字
# path        临时表空间数据文件的位置
# size m    表示临时表空间的大小
create temporary tablespace euansu_temp tempfile '/home/oracle/euansu_temp' size 10M;
```

![image-20220714192306181](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714192306181.png)

![image-20220714192328271](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714192328271.png)

创建用户

```sql
create user euansu identified by "suwenhui123" default tablespace euansu temporary tablespace euansu_temp;

# tablespace            表空间
# temporary tablespace    临时表空间
# 创建用户时会报65096的错误，执行如下语句即可：
alter session set "_ORACLE_SCRIPT"=true;
```

![image-20220714192445471](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714192445471.png)

# Python连接Oracle

## 安装 cx_Oracle 第三方库 

最新 cx_Oracle 并不支持 Python2.7，这里下载支持 Python2.7 的7.3.0 版本，下载地址：https://files.pythonhosted.org/packages/5e/e3/cfd4f413f8d47dd2aee09273d9bb3ee6aa7384e0a04e191d703c2199eb93/cx_Oracle-7.3.0.tar.gz

![image-20220817174623225](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220817174623225.png)

```shell
# 解压 cx_Oracle 源码包
tar -zxvf cx_Oracle-7.3.0.tar.gz
# 安装 cx_Oracle 第三方库
python2.7 setup.py install
```

![image-20220817175001764](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220817175001764.png)

## 安装 Oracle Instant Client

通过 python 连接 oracle 需要使用 cx_Oracle 第三方库，要求主机提前安装 Oracle Instant Client，否则连接 Oracle 会报如下错误。

![image-20220817173612608](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220817173612608.png)

### 下载 Oracle Instant Client

下载地址：https://www.oracle.com/database/technologies/instant-client/linux-x86-64-downloads.html，下载对应版本的 Oracle Instant Client包即可。

![image-20220817173734432](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220817173734432.png)

### 创建 Oracle Instant Clinet 所需目录

```shell
sudo mkdir -p /opt/oracle
sudo mv instantclient-basic-linux.x64-21.7.0.0.0dbru.zip /opt/oracle/
cd /opt/oracle
sudo unzip instantclient-basic-linux.x64-21.7.0.0.0dbru.zip
```

### 安装系统  libaio 包

```shell
sudo yum install libaio
```

### 创建 Instant Client 的 .so 文件依赖

```shell
sudo sh -c "echo /opt/oracle/instantclient_21_7 > /etc/ld.so.conf.d/oracle-instantclient.conf"
sudo ldconfig
```

### 添加 Instant Clinet 的环境变量

```shell
export LD_LIBRARY_PATH=/opt/oracle/instantclient_21_7:$LD_LIBRARY_PATH
```

### 测试连接

![image-20220817180349849](/oracle%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220817180349849.png)

## Python 连接 Oracle 封装代码

```python
import cx_Oracle
class OracleApi(object):

    def __init__(self, host, port, user, password, instant):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.instant = instant

    def connect(self):
        self.conn = cx_Oracle.connect(self.user, self.password, '%s:%s/%s' % (self.host, self.port,self.instant))
        self.cursor = self.conn.cursor()

    def close(self):
        self.cursor.close()
        self.conn.close()

    def get_one(self, sql, params=()):
        result = None
        try:
            self.connect()
            self.cursor.execute(sql, params)
            result = self.cursor.fetchone()
            self.close()
        except Exception, e:
            print e.message
        return result

    def get_all(self, sql):
        list = ()
        try:
            self.connect()
            self.cursor.execute(sql)
            list = self.cursor.fetchall()
            self.close()
        except Exception, e:
            print e.message
        return list
```

