---
title: PGSQL 使用记录
createTime: 2022/07/13 10:57:38
permalink: /article/python_connect_pgsql/
tags:
  - Python
  - PGSQL
---

PostgreSQL 被业界誉为“世界上最先进的开源关系型数据库”，虽然 PostgreSQL 是关系型数据库，但其也支持 NoSQL 数据类型（JSON/XML/hstore），并且性能甚至超过了 MongoDB。

<!--more-->

# PGSQL 操作

## PGSQL CLI

```shell
# pgsql部署执行执行如下操作
sudo su - postgres
psql
```

![image-20220708171039813](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708171039813.png)

## PGSQL 客户端连接

```shell
# 使用客户端连接使用
psql -h 133.0.120.49 -p 18921 --username=flink_cdc --password
```

![image-20220714101916339](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714101916339.png)

## PGSQL 语句操作

创建用户

```sql
create user "suwh" with password 'suwenhui@2022'; 
```

![image-20220708201523982](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708201523982.png)

创建库

```sql
create database suwh with owner suwh;
```

获取pgsql所有的库

```sql
select * from pg_database;
```

![image-20220708153713056](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708153713056.png)

获取pgsql所有的表

```sql
SELECT  tablename  FROM  pg_tables  WHERE  tablename NOT LIKE'pg%'  AND tablename NOT LIKE'sql_%'  ORDER BY  tablename;
```

![image-20220709113315958](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220709113315958.png)

创建pgsql表

```sql
# 创建表
CREATE TABLE COMPANY(
   ID INT PRIMARY KEY     NOT NULL,
   NAME           TEXT    NOT NULL,
   AGE            INT     NOT NULL,
   ADDRESS        CHAR(50),
   SALARY         REAL
);

# 插入数据
INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) VALUES (1, 'Allen', 25, 'Texas', 10000);
INSERT INTO COMPANY (ID,NAME,AGE,ADDRESS,SALARY) VALUES (3, 'euansu', 25, 'Texas', 10000.9);
```

查询pgsql表结构

```sql
SELECT   A.ordinal_position,   A.column_name,   CASE A.is_nullable WHEN 'NO' THEN 0 ELSE 1END AS is_nullable,   A.data_type,   coalesce(A.character_maximum_length, A.numeric_precision, -1) as length,   B.COMMENT,   CASE WHEN length(B.attname) > 0 THEN 1 ELSE 0 END AS is_pk  FROM   information_schema.columns A  LEFT JOIN (   SELECT     pg_attribute.attname,     col_description ( pg_attribute.attrelid, pg_attribute.attnum ) AS COMMENT   FROM     pg_index,     pg_class,     pg_attribute   WHERE     pg_class.oid = 'company'::regclass   AND pg_index.indrelid = pg_class.oid   AND pg_attribute.attrelid = pg_class.oid   AND pg_attribute.attnum = ANY(pg_index.indkey)  ) B ON A.column_name = b.attname  WHERE   A.table_schema = 'public'  AND A.table_name = 'company'  ORDER BY   ordinal_position ASC;
```

![image-20220708171255127](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708171255127.png)

## PGSQL 数据类型

| 名字                                      | 别名                 | 描述                           |
| --------------------------------------- | ------------------ | ---------------------------- |
| bigint                                  | int8               | 有符号8字节整数                     |
| bigserial                               | serial8            | 自增8字节整数                      |
| bit [ (n) ]                             |                    | 定长位串                         |
| bit varying [ (n) ]                     | varbit             | 可变长位串                        |
| boolean                                 | bool               | 逻辑布尔值(真/假)                   |
| box                                     |                    | 平面上的矩形                       |
| bytea                                   |                    | 二进制数据("字节数组")                |
| character varying [(n)]                 | varchar [(n)]      | 可变长字符串                       |
| cidr                                    |                    | IPv4 或 IPv6 网络地址             |
| circle                                  |                    | 平面上的圆                        |
| date                                    |                    | 日历日期(年, 月, 日)                |
| double precision                        | float8             | 双精度浮点数(8字节)                  |
| inet                                    |                    | IPv4 或 IPv6 主机地址             |
| integer                                 | int, int4          | 有符号 4 字节整数                   |
| interval [ fields ] [ (p) ]             |                    | 时间间隔                         |
| line                                    |                    | 平面上的无限长直线                    |
| lseg                                    |                    | 平面上的线段                       |
| macaddr                                 |                    | MAC (Media Access Control)地址 |
| money                                   |                    | 货币金额                         |
| numeric [ (p, s) ]                      | decimal [ (p, s) ] | 可选精度的准确数值数据类型                |
| path                                    |                    | 平面上的几何路径                     |
| point                                   |                    | 平面上的点                        |
| polygon                                 |                    | 平面上的封闭几何路径                   |
| real                                    | float4             | 单精度浮点数(4 字节)                 |
| smallint                                | int2               | 有符号 2 字节整数                   |
| smallserial                             | serial2            | 自增 2 字节整数                    |
| serial                                  | serial4            | 自增 4 字节整数                    |
| text                                    |                    | 可变长字符串                       |
| time [ (p) ] [ without time zone ]      |                    | 一天中的时刻(无时区)                  |
| time [ (p) ] with time zone    timetz   |                    | 一天中的时刻，含时区                   |
| timestamp [ (p) ] [ without time zone ] |                    | 日期与时刻(无时区)                   |
| timestamp [ (p) ] with time zone        | timestamptz        | 日期与时刻，含时区                    |
| tsquery                                 |                    | 文本检索查询                       |
| tsvector                                |                    | 文本检索文档                       |
| txid_snapshot                           |                    | 用户级别的事务ID快照                  |
| uuid                                    |                    | 通用唯一标识符                      |
| xml                                     |                    | XML 数据                       |
| json                                    |                    | JSON 数据                      |

# Python 连接 PGSQL

```python
# 配置的用户 suwh 无数据库。
conn = psycopg2.connect(host='172.21.3.82', port='5432', user='suwh', password='suwenhui@2022')
```

![image-20220708202731870](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708202731870.png)

给用户 `suwh` 创建库后，正常连接。

![image-20220708202958091](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220708202958091.png)

# Python 连接 PGSQL 报错

（1）问题现象

SCRAM authentication requires libpq version 10 or above。

（2）问题结论

libpq 包版本低于10版本，升级 libpq 包版本，使用最新的 libpq.so 包替换原有的 libpq.so 包。

![image-20220714101702399](/pgsql%E8%BF%9E%E6%8E%A5%E4%BD%BF%E7%94%A8/image-20220714101702399.png)
