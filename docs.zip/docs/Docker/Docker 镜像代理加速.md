---
title: Docker 镜像代理加速
createTime: 2024/11/06 12:57:38
permalink: /article/docker_proxy/
tags:
  - Docker
---

# Docker 镜像代理加速

搭建 `Docker` 镜像站需要一台能连接到 `docker.io` 的服务器，这里暂无条件，通过已经搭建好的代理镜像站进行镜像的拉取即可。

## systemd 管理 Docker 服务

通过发布包而不是 `rpm` 包安装的 `Docker`，这里首先将 `Docker` 加入到 `systemd` 服务中进行管理，只需要在 `systemd` 的目录下，新增 `docker.service` 配置文件即可。

- 新增 `docker.service` 配置文件。

  ```shell
  sudo vim /etc/systemd/system/docker.service
  ```

- 写入 `Docker` 服务的相关信息，如下所示，注意要修改 `ExecStart`，也即 `docker` 服务实际所在的目录。

  ```ini
  [Unit]
  Description=Docker Application Container Engine
  Documentation=https://docs.docker.com
  After=network-online.target firewalld.service
  Wants=network-online.target
  
  [Service]
  Type=notify
  ExecStart=/usr/bin/dockerd
  ExecReload=/bin/kill -s HUP $MAINPID
  TimeoutSec=0
  RestartSec=2
  Restart=always
  
  # Note that StartLimit* options were moved from "Service" to "Unit" in systemd 229.
  # Both the old, and new location are accepted by systemd 229 and up, so using the old location
  # to make them work for either version of systemd.
  StartLimitBurst=3
  
  # Note that StartLimitInterval was renamed to StartLimitIntervalSec in systemd 230.
  StartLimitInterval=60s
  
  # Having non-zero Limit*s causes performance problems due to accounting overhead
  # in the kernel. We recommend using cgroups to do container-local accounting.
  LimitNOFILE=1048576
  LimitNPROC=1048576
  LimitCORE=infinity
  
  # Uncomment TasksMax if your systemd version supports it.
  # Only systemd 226 and above support this version.
  TasksMax=infinity
  Delegate=yes
  KillMode=process
  
  [Install]
  WantedBy=multi-user.target
  ```

- 重启 `Docker` 服务。

  ```shell
  # 检查docker的进程
  ps -ef | grep docker
  # kill掉docker进程
  kill -9 $pid
  # 使用systemctl命令启动docker服务
  sudo systemctl start docker
  # 检查docker服务的状态
  sudo systemctl status docker
  ```

## Docker 镜像加速器配置

`Docker` 的配置文件 `/etc/docker/daemon.json` 中可以添加镜像加速器的信息，如未配置，则无法通过镜像代理拉取镜像。

- `Docker` 配置文件中添加镜像加速器信息，这里可以添加多个，目前只是配置了一个可用的 `Docker` 代理镜像源。

  ```shell
  {
      "registry-mirrors": [
          "https://dockerpull.org"
      ]
  }
  ```

- 重启 `Docker` 服务。

  ```shell
  # 通知 systemd 重新加载 Docker 服务配置文件
  sudo systemctl daemon-reload
  # 通知 systemd 重启 Docker 服务
  sudo systemctl restart docker
  ```

- 拉取 `Docker` 镜像测试。

  以拉取 `mysql` 镜像为例，原来拉取 `mysql` 镜像 直接执行 `docker pull mysql:tag`，现在拉取则是要在 `mysql:tag` 的前面添加镜像源信息，如 `dockerpull.org`，完整的命令如下所示。

  ```shell
  sudo docker pull dockerpull.org/mysql
  ```

  ![image-20241106113646227](/Docker镜像代理加速/image-20241106113646227.png)