---
title: Docker操作笔记
createTime: 2024/03/02 11:57:38
permalink: /article/docker_notebook/
tags:
  - Docker
---

# Docker 基础笔记

## Docker 部署 MySQL

使用如下命令直接部署一个 `MySQL`容器。

```shell
$ docker run --name mysql -p 13306:3306 -e TZ=Asia/Shanghai -e MYSQL_ROOT_PASSWORD=euansu123 -d mysql
```

![image-20240908000019978](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908000019978.png)

`MySQL` 容器运行成功，使用数据库工具连接 `MySQL`，显示能够正常连接 `MySQL`容器部署成功。

![image-20240908000818011](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908000818011.png)

`docker run` 实际上是一条运行镜像的命令，当我们使用 `Docker` 进行容器的运行时，`Docker` 首先会在本地搜索镜像，如果在本地没有找到镜像就会到远程仓库自动搜索并下载镜像。镜像不仅包含应用本身，还包含应用运行所需要的环境、配置、系统函数库。`Docker` 会在运行镜像时创建一个隔离的环境，称为容器。

## Docker 命令

下图所示为 Docker 的常见命令，也即操作容器、镜像的命令。

![Snipaste_2024-09-07_23-40-08](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/Snipaste_2024-09-07_23-40-08.png)

执行 `docker --help` 就能够查询当前版本 `docker` 所支持的命令。 

```shell
$ docker --help
# 常用命令
  run         通过镜像创建并运行一个新的容器
  exec        在运行的容器执行一个命令
  ps          容器列表
  build       通过Dockerfile编译一个镜像
  pull        从Docker镜像仓库下载一个镜像
  push        推送镜像到镜像仓库
  images      镜像列表
  login       登录到Docker仓库
  logout      注销Docker仓库的登录操作
  search      搜索Docker镜像
  version     Docker的版本信息
  info        显示系统范围的信息

# 管理命令
  builder     Manage builds
  container   Manage containers
  context     Manage contexts
  image       Manage images
  manifest    Manage Docker image manifests and manifest lists
  network     Manage networks
  plugin      Manage plugins
  system      Manage Docker
  trust       Manage trust on Docker images
  volume      Manage volumes

Swarm Commands:
  swarm       Manage Swarm

# 命令
Commands:
  attach      介入到一个正在运行的容器
  commit      根据容器的更改创建一个新的镜像
  cp          在容器和本地文件系统之间拷贝文件和目录
  create      创建一个新的容器
  diff        Inspect changes to files or directories on a container's filesystem
  events      Get real time events from the server
  export      Export a container's filesystem as a tar archive
  history     Show the history of an image
  import      Import the contents from a tarball to create a filesystem image
  inspect     Return low-level information on Docker objects
  kill        Kill一个或多个正在运行的容器
  load        通过tar压缩文件或STDIN（输入流文件）加载一个镜像
  logs        获取容器的日志
  pause       暂停一个或多个容器的所有进程
  port        List port mappings or a specific mapping for the container
  rename      重名一个容器
  restart     重启一个或多个容器
  rm          删除一个或多个容器
  rmi         删除一个或多个镜像
  save        保存一个或多个镜像文件为一个tar压缩文件
  start       启动一个或多个已经停止的容器
  stats       显示一个容器的实时资源占用
  stop        停止一个或多个正在运行的容器
  tag         为镜像创建一个新的标签
  top         显示一个容器中正在运行的进程
  unpause     恢复一个或多个容器内所有被暂停的进程
  update      更新一个或多个容器的配置
  wait        Block until one or more containers stop, then print their exit codes

# 全局选项
      --config string      Location of client config files (default "/root/.docker")
  -c, --context string     Name of the context to use to connect to the daemon (overrides DOCKER_HOST env var and default context set with "docker
                           context use")
  -D, --debug              Enable debug mode
  -H, --host list          Daemon socket to connect to
  -l, --log-level string   Set the logging level ("debug", "info", "warn", "error", "fatal") (default "info")
      --tls                Use TLS; implied by --tlsverify
      --tlscacert string   Trust certs signed only by this CA (default "/root/.docker/ca.pem")
      --tlscert string     Path to TLS certificate file (default "/root/.docker/cert.pem")
      --tlskey string      Path to TLS key file (default "/root/.docker/key.pem")
      --tlsverify          Use TLS and verify the remote
  -v, --version            Print version information and quit
```

## Docker 数据卷挂载

数据卷（volume）是一个虚拟目录，是容器内目录与宿主机目录之间映射的桥梁。

![image-20240908002031492](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908002031492.png)

在创建容器时，利用 `-v 数据卷名称:容器内目录` 完成挂载，如果发现挂载的数据卷不存在，会自动进行创建。

```shell
docker run -d --name nginx -p 1800:80 -v html:/usr/share/nginx/html nginx
```

![image-20240908101015335](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908101015335.png)

使用 `docker volume inspect html` 即可查看新建挂载卷的信息，`Mountpoint` 也即挂载卷在主机上的路径。

修改 `Mountpoint` 中 `index.html` 的内容。

![image-20240908101556596](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908101556596.png)

使用浏览器访问 `主机IP:1800`，页面显示的内容发生了改变。

![image-20240908101626768](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908101626768.png)

数据卷的常见命令有：

- `docker volume ls`，查看数据卷
- `docker volume rm`，删除数据卷
- `docker volume inspect`，查看数据卷详情
- `docker volume prune` ，删除未使用的数据卷

## Docker 本地目录挂载

本地目录挂载与数据卷相比语法几乎一致，只是前者挂载的是数据卷，后者是本地目录，在创建容器时，利用 `-v 本地目录:容器内目录` 完成挂载，如果发现挂载的数据卷不存在，会自动进行创建。

```shell
# 创建并运行一个docker容器，挂载主机上的/www/html目录到容器的/usr/share/nginx/html目录
docker run -d --name nginx -p 1800:80 -v /www/html:/usr/share/nginx/html nginx
```

执行如上命令后，就运行了一个 `nginx` 容器，并完成了本地目录的挂载。

![image-20240908003058548](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908003058548.png)

浏览器访问 `主机IP:1800` 地址，显示 `403` 也即无法访问到资源。

![image-20240908003904501](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908003904501.png)

这是因为本地目录 `/www/html` 中没有放入静态资源文件，拷贝 `index.html` 到数据卷中。

![image-20240908004053470](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908004053470.png)

再次访问就能够看到 `nginx` 代理页面出现了内容，也即本地挂载的内容在容器内能够正常访问。

![image-20240908004238798](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908004238798.png)

## Dockerfile 语法

Dockerfile 就是一个文本文件，其中包含一个个的指令（Instruction），用指令来说明要执行什么操作来构建镜像，将来 Docker 可以根据 Dockerfile 帮助我们构建镜像，常见指令如下：

| 指令       | 说明                                         | 示例                                        |
| ---------- | -------------------------------------------- | ------------------------------------------- |
| FROM       | 指定基础镜像                                 | FROM centos:6                               |
| ENV        | 设置环境变量，可在后面指令使用               | ENV key value                               |
| COPY       | 拷贝本地文件到镜像的执行目录                 | COPY ./index.html /usr/share/nginx/html     |
| RUN        | 执行Linux的shell命令，一般是安装过程的命令   | RUN apt-get update -y && apt-get install -y |
| EXPOSE     | 指定容器运行时监听的端口，是给镜像使用者看的 | EXPOSE 8888                                 |
| ENTRYPOINT | 指定默认的可执行文件                         | ENTRYPOINT python manage.py runserver       |
| CMD        | 指定默认运行的命令                           | CMD ["./startup.sh"]                        |
| WORKDIR    | 设置容器内的工作目录                         | WORKDIR /usr/share/hue                      |

这里提供一个 `HUE(使用django框架的大数据工具)`的 `Dockerfile` 以供参考。

```dockerfile
# Welcome to Hue (http://gethue.com) Dockerfile

FROM ubuntu:20.04
LABEL description="Hue SQL Assistant - gethue.com"

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update -y && apt-get install -y \
  python3-pip \
  libkrb5-dev  \
  libsasl2-modules-gssapi-mit \
  libsasl2-dev \
  libkrb5-dev \
  krb5-config \
  krb5-user \
  libxml2-dev \
  libxslt-dev \
  libmysqlclient-dev \
  libldap2-dev \
  libsnappy-dev \
  python3.8-venv \
  python3.8-dev \
  python3.8-distutils \
  rsync \
  curl \
  sudo \
  git && \
  rm -rf /var/lib/apt/lists/*

ADD . /hue

RUN pip3 install --upgrade --no-cache-dir setuptools virtualenv pip && \
  apt-get install -y curl && \
  curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash - && \
  apt-get install -y nodejs && \
  addgroup hue && \
  useradd -r -u 1001 -g hue hue && \
  chown -R hue /hue && \
  mkdir /hue/build && \
  chown -R hue /hue/build && \
  mkdir /usr/share/hue && \
  chown -R hue /usr/share/hue && \
  rm -rf /hue/desktop/conf && \
  cp -r /hue/desktop/conf.dist /hue/desktop/conf && \
  mkdir -m 755 /var/log/hue && \
  cd /hue && \
  ln -fs /usr/local/bin/pip3.8 /usr/bin/pip3.8 && \
  ln -fs /usr/local/bin/pip3.8 /usr/bin/pip3 && \
  PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python \
  PREFIX=/usr/share ROOT=/usr/share/hue PYTHON_VER=python3.8 ROOT=/hue \
  SYS_PYTHON=/usr/bin/python3.8 SYS_PIP=/usr/local/bin/pip3.8 make apps install && \
  chown -R hue /usr/share/hue && \
  npm cache clean --force && \
  pip cache purge && \
  rm -rf /var/lib/apt/lists/* && \
  cp -r /hue/tools/docker/hue/conf3/* /usr/share/hue/desktop/conf/ && \
  cp /hue/tools/docker/hue/startup.sh /usr/share/hue/startup.sh && \
  mkdir -p /usr/share/hue/tools/slack && \
  cp /hue/tools/slack/manifest.yml /usr/share/hue/tools/slack/manifest.yml && \
  rm -rf /hue && \
  rm -rf /usr/share/hue/node_modules

WORKDIR /usr/share/hue

# Install DB connectors
# To move to requirements_connectors.txt
RUN ./build/env/bin/pip install --no-cache-dir \
  psycopg2-binary \
  # Avoid Django 3 pulling \
  django_redis==4.11.0 \
  flower==0.9.7 \
  # Contains fix for SparkSql show tables \
  git+https://github.com/gethue/PyHive \
  #ksql \
  git+https://github.com/bryanyang0528/ksql-python \
  pydruid \
  # pybigquery \
  elasticsearch-dbapi \
  pyasn1==0.4.1 \
  # View some parquet files \
  python-snappy==0.5.4 \
  # Needed for Jaeger \
  threadloop \
  # Fix Can't load plugin: sqlalchemy.dialects:clickhouse \
  sqlalchemy-clickhouse \
  # sqlalchemy-clickhouse depend on infi.clickhouse_orm \
  # install after sqlalchemy-clickhouse and version == 1.0.4 \
  # otherwise Code: 516, Authentication failed will display \
  infi.clickhouse_orm==1.0.4 \
  mysqlclient==2.1.1 \
  PyAthena==2.25.2
  # PyAthena == 3.x.x is latest, but not working with current configuration \
  # otherwise, 'VisitableType' object is not subscriptable in Hue UI

USER hue

EXPOSE 8888

CMD ["./startup.sh"]
```

## Docker 自定义镜像

```dockerfile
# 基础镜像
FROM ubuntu:20.04
# 指定工作目录
WORKDIR /usr/share/Gin
# 拷贝本地文件
COPY ./GinExm /usr/local/Gin/
# 安装系统环境依赖
RUN apt-get update -y && apt-get install -y vim
# 授予文件可执行权限、创建用户
RUN chmod a+x /usr/local/Gin/GinExm && addgroup euansu &&  useradd -r -u 1001 -g euansu euansu
# 指定用户
USER euansu
# 指定容器运行时监听的端口
EXPOSE 8888
# 默认执行的命令
CMD ["/usr/local/Gin/GinExm"]
```

![image-20240908013312126](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908013312126.png)

这里我们直接运行构建完成的 `ginexm` 镜像，如下所示。

```shell
docker run --name GinExm -p 8888:8888 -d ginexm:1.0
```

![image-20240908013611919](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908013611919.png)

运行完成后，浏览器访问 `主机IP:8888`，镜像运行成功，自定义镜像成功。

![image-20240908013815257](/Docker%E6%93%8D%E4%BD%9C%E7%AC%94%E8%AE%B0/image-20240908013815257.png)

## 相关链接

[1] docker官方文档 https://docs.docker.com/go/guides/

[2] docker中文官网 https://www.docker.org.cn/

[3] docker中文文档 http://www.dockerinfo.net/document

[4] docker中文指南 https://www.widuu.com/chinese_docker/index.html