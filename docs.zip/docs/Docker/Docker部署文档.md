---
title: Linux主机部署Docker
createTime: 2024/02/20 11:57:38
permalink: /article/docker_deploy/
tags:
  - Docker
---

# Docker部署

## 1.二进制文件部署

- 到如下地址，下载二进制包。

  Docker官网（X86）：https://download.docker.com/linux/static/stable/x86_64/

  Docker官网（ARM）：https://download.docker.com/linux/static/stable/aarch64/

  网易镜像源（X86）：https://mirrors.163.com/docker-ce/linux/static/stable/x86_64/

  网易镜像源（ARM）：https://mirrors.163.com/docker-ce/linux/static/stable/aarch64/

- 下载好的二进制包上传到主机，进行解压。

  ```shell
  tar -zxvf docker-20.10.24.tgz
  ```

  ![image-20231106150209515](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20231106150209515.png)

- 移动解压后的文件到系统路径，或设置环境变量。

  ```shell
  sudo cp docker/* /usr/bin/
  ```

  ![image-20231106150545168](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20231106150545168.png)

- 启动docker。

  ```
  sudo dockerd &
  ```

  ![image-20231106150755770](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20231106150755770.png)

- 测试Docker是否安装成功。

  ```shell
  sudo docker version
  ```

  ![image-20231106151246803](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20231106151246803.png)

## 2.普通用户使用docker

1. 创建docker用户组，并将普通用户添加至docker组
   如果docker组不存在的话，需要先行创建

   ```shell
   sudo groupadd docker
   ```
   将用户添加至docker用户组，$USER 用户名称
   ```shell
   sudo usermod -aG docker $USER
   ```
   被添加的用户并不会立即生效，需要注销后重新进行登录
   ```shell
   newgrp docker
   ```

2. 重新启动docker服务

   检查先前启动docker的进程id

   ```shell
   ps -ef | grep docker
   ```

   kill掉之前启动的docker进程

   ```shell
   sudo kill -9 $docker-pid
   ```

   ![image-20240220111535746](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20240220111535746.png)

3. 确保用户有访问 docker.socket 文件的权限。

   ```shell
   sudo chown :docker /var/run/docker.sock
   sudo chown :docker /var/run/docker
   sudo chown :docker /usr/bin/docker
   ```

4. 普通用户执行docker命令进行确认。

   ```shell
   docker version
   ```

   出现下图所示，普通用户能够正常使用docker，后期不再需要sudo权限。

   ![image-20240220111716705](/Docker%E9%83%A8%E7%BD%B2%E6%96%87%E6%A1%A3/image-20240220111716705.png)