---
title: Nginx 基础概念及使用
createTime: 2023/07/18 10:57:38
permalink: /article/nginx_base_and_tutorial/
tags:
  - Nginx
---

Nginx是一个高性能的web服务器和反向代理服务器，以其低内存使用率和强大的并发能力而闻名。它最初由Igor Sysoev编写，并以类似BSD的2条款许可证发行。Nginx可以处理各种协议，如HTTP、TCP、UDP、IMAP、POP3和SMTP。它被Yandex、Mail.Ru、VK、Rambler、Dropbox、Netflix、Wordpress.com、FastMail.FM等许多负载沉重的网站广泛使用和信任。

<!--more-->

# 正向代理和反向代理

## 正向代理

### 概念

![在这里插入图片描述](/nginx%E5%9F%BA%E7%A1%80/49d52f5b79a140fd8c131f8fe115bf60tplv-k3u1fbpfcp-zoom-in-crop-mark3024000.jpg)

### 特点

- 正向代理需要主动设置代理服务器 ip 或域名进行访问，由设置的ip 或域名去访问内容并返回。
- 正向代理是代理客户端，为客户端收发请求，使得真实的客户端对服务器不可见。

### 概念

![在这里插入图片描述](/nginx%E5%9F%BA%E7%A1%80/23e94f266d6c44ed95f20053ee973bd4tplv-k3u1fbpfcp-zoom-in-crop-mark3024000.jpg)

### 特点

- 正向代理需要配置代理服务器，而反向代理不需要做任何设置。
- 反向代理是代理服务器，为服务器收发请求，使得真实服务器对客户端不可见。

## 正向代理和反向代理的比较

### 相同点

- 正向代理和反向代理所处的位置都是客户端与真实提供服务的服务器之间。
- 正向代理和反向代理都是把客户端的请求转发给服务器，再把服务器的响应转发给客户端。

### 不同点

- 正向代理是客户端的代理，服务器并不知道真正的客户端是谁，反向代理是服务器的代理，客户端并不知道真正的服务器是谁；
- 正向代理一般是客户端架设，反向代理一般是服务器架设；
- 正向代理主要是为了解决访问限制问题，反向代理主要是为了提供负载均衡、安全防护等。

# Nginx 负载均衡

## 概念

负载均衡，英文名称为Load Balance，其含义就是指将负载（工作任务）进行平衡、分摊到多个操作单元上进行运行，例如FTP服务器、Web服务器、企业核心应用服务器和其它主要任务服务器等，从而协同完成工作任务。

负载均衡构建在原有网络结构之上，它提供了一种透明且廉价有效的方法扩展服务器和网络设备的带宽、加强网络数据处理能力、增加吞吐量、提高网络的可用性和灵活性。

简言之，负载均衡实际上就是将大量请求进行分布式处理的策略。

## 负载均衡实现

```nginx
upstream testServer {
        server localhost:8081;
        server localhost:8082;
        server localhost:8083;
   }


server {
        listen       8000;
        server_name  localhost;

        location / {
            root   html;
            index  index.html index.htm;
            proxy_pass http://testServer;
        }
    }
```

localhost:8081、localhost:8082、localhost:8083分别为如下页面：

![](/nginx%E5%9F%BA%E7%A1%80/2022-07-19-20-27-57-image.png) 

![](/nginx%E5%9F%BA%E7%A1%80/2022-07-19-20-28-39-image.png)

![](/nginx%E5%9F%BA%E7%A1%80/2022-07-19-20-28-50-image.png)

访问 localhost:8000 会出现如上页面。

## 负载均衡常用算法

### 轮询

轮询为负载均衡中较为基础也较为简单的算法，它不需要配置额外参数。假设配置文件中共有 **M** 台服务器，该算法遍历服务器节点列表，并按节点次序每轮选择一台服务器处理请求。当所有节点均被调用过一次后，该算法将从第一个节点开始重新一轮遍历。



# Nginx 安装

## 依赖库安装

```shell
# gcc g++
sudo yum install build-essential
sudo yum install libtool

# pcre
sudo yum install libpcre3 libpcre3-dev

# zlib
sudo yum install zlib1g-dev

# ssl
sudo yum install openssl
sudo yum install libssl-dev
```

## Nginx 源码编译安装

```shell
# 下载
$ wget https://nginx.org/download/nginx-1.17.8.tar.gz
# 解压
$ tar -zxvf nginx-1.17.8.tar.gz
# 进入目录
$ cd nginx-1.17.8
# 配置，这里可能会报错，缺少啥就去安装啥
$ ./configure --prefix=/usr/local/nginx \
--with-http_gzip_static_module \
--with-http_v2_module \
--with-pcre \
--with-http_ssl_module
# 生成makefile文件
make
# 安装
make install
```

# Nginx 代理二级域名

新增一个 `server` 块，监听的端口依然是 80 端口，如果配置的端口为非 80 端口，则需要携带端口访问 http 服务。

```nginx
server {
       listen       80;
       server_name  cloud.euansu.cn;
       index index.php;

       #location / {
       #    proxy_set_header Host $http_host;
        #   proxy_pass http://cloud.euansu.cn:8000;
       #}
       location / {
           root         /kodbox;
       }

       location ~ \.php$ {
           root           /kodbox;
           fastcgi_pass   127.0.0.1:9000;
           fastcgi_index  index.php;
           fastcgi_param  SCRIPT_FILENAME  /kodbox$fastcgi_script_name;
           include        fastcgi_params;
        }
    }
```

# Nginx 配置https

新增一个 `server` 块，监听的端口依然是 443 端口，如果配置的端口为非 443 端口，则需要携带端口访问 https 服务。

```nginx
server {
        listen       443 ssl;
        server_name  cloud.euansu.cn;
        index index.php;

        ssl_certificate      /www/nginx/cert/cloud.euansu.cn.pem;
        ssl_certificate_key  /www/nginx/cert/cloud.euansu.cn.key;

        ssl_session_cache    shared:SSL:1m;
        ssl_session_timeout  5m;

        ssl_ciphers  HIGH:!aNULL:!MD5;
        ssl_prefer_server_ciphers  on;

        location / {
           root         /kodbox;
       }

       location ~ \.php$ {
           root           /kodbox;
           fastcgi_pass   127.0.0.1:9000;
           fastcgi_index  index.php;
           fastcgi_param  SCRIPT_FILENAME  /kodbox$fastcgi_script_name;
           include        fastcgi_params;
        }
    }
```
