---
title: Nginx 日志配置
createTime: 2024/05/29 10:57:38
permalink: /article/nginx_log_configure/
tags:
  - Nginx
---

# Nginx 日志配置

Nginx 主要有两种日志类型：访问日志（access log）和错误日志（error log），可以帮助监控和调试服务的运行。

## 1.访问日志

访问日志主要记录客户端的请求，客户端向 Nginx 发起的每一次都会被记录到访问日志中。客户端IP、浏览器信息等都可以在访问日志中获取得到，具体的日志记录格式可以通过 `log_format` 来进行定义。

### 1.1 语法

```nginx
# 设置访问日志
access_log  path  [format [buffer=size] [gzip[=level]] [flush=time] [if=condition]];
# 关闭访问日志
access_log  off;
```

访问日志设置字段说明：

- path：指定访问日志的存储路径。
- format：指定日志的格式。
- buffer：用来指定日志写入时的缓存大小，默认是64K。
- gzip：日志写入前先进行压缩，从 1 到 9 数值越大压缩比越高，同事压缩的速度也越慢，默认为 1。
- flush：设置缓存的有效时间，如果超过 flush 指定的时间，缓存中的内容将被清空。
- if：条件判断，如果指定的条件计算为0或空字符串，那么该请求不会写入日志。

### 1.2 作用域

可以使用 access_log 日志的作用域有：http、server、loaction、limit_except，如果在这几个作用域之外使用 access_log ，Nginx 会报错。

### 1.3 基础使用

指定 access_log 的日志写入路径为 Nginx 目录下 logs/access.log 文件。

```nginx
access_log logs/access.log
```

指定 access_log 的日志写入路径为 Nginx 目录下 logs/access.log 文件，日志的缓存大小为 32K，日志写入前启用 gzip 进行压缩，压缩比使用默认值 1，缓存数据有效时间为 1 分钟。

```nginx
access_log logs/access.log buffer=32k gzip flush=1m
```

### 1.4 log_format 自定义日志格式

Nginx 预定义了日志格式，如果没有明确指定日志格式将使用预定义的日志格式。

```nginx
log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                  '$status $body_bytes_sent "$http_referer" '
                  '"$http_user_agent" "$http_x_forwarded_for"';
```

如果需要修改，参考 log_format 的语法进行修改即可。

```nginx
log_format name [escape=default|json] string ...;
```

log_format 语法字段说明：

- name：格式名称，在 access_log 中显性引用，否则会使用默认的语法。
- escape：置变量中的字符编码方式是 json 还是 default ，默认是 default。
- stirng：要定义的日志格式内容，该参数可以有多个，参数中可以使用Nginx变量。

如下是 log_format 中常用的一些变量：

| 变量                  | 含义                                                         |
| --------------------- | ------------------------------------------------------------ |
| $bytes_sent           | 发送给客户端的总字节数                                       |
| $body_bytes_sent      | 发送给客户端的字节数，不包括响应头的大小                     |
| $connection           | 连接序列号                                                   |
| $connection_requests  | 当前通过连接发出的请求数量                                   |
| $msec                 | 日志写入时间，单位为秒，精度是毫秒                           |
| $pipe                 | 如果请求是通过http流水线发送，则其值为"p"，否则为“."         |
| $request_length       | 请求长度（包括请求行，请求头和请求体）                       |
| $request_time         | 请求处理时长，单位为秒，精度为毫秒，从读入客户端的第一个字节开始，直到把最后一个字符发送张客户端进行日志写入为止 |
| $status               | 响应状态码                                                   |
| $time_iso8601         | 标准格式的本地时间,形如“2017-05-24T18:31:27+08:00”           |
| $time_local           | 通用日志格式下的本地时间，如"24/May/2017:18:31:27 +0800"     |
| $http_referer         | 请求的referer地址。                                          |
| $http_user_agent      | 客户端浏览器信息。                                           |
| $remote_addr          | 客户端IP                                                     |
| $http_x_forwarded_for | 当前端有代理服务器时，设置web节点记录客户端地址的配置，此参数生效的前提是代理服务器也要进行相关的x_forwarded_for设置。 |
| $request              | 完整的原始请求行，如 "GET / HTTP/1.1"                        |
| $remote_user          | 客户端用户名称，针对启用了用户认证的请求                     |
| $request_uri          | 完整的请求地址，如 "https://daojia.com/"                     |

### 1.5 访问日志配置测试

关闭访问日志，客户端向 Nginx 服务器发起请求，访问日志未记录。

```nginx
access_log off;
```

![image-20240530000937474](/nginx%E6%97%A5%E5%BF%97%E9%85%8D%E7%BD%AE/image-20240530000937474.png)

开启访问日志，使用预定义的 log_format，日志按照预定义的格式进行打印。

```nginx
access_log  logs/access.log;
```

![image-20240530001219876](/nginx%E6%97%A5%E5%BF%97%E9%85%8D%E7%BD%AE/image-20240530001219876.png)

开启访问日志，使用自定义的 log_format，能够按照指定的格式进行打印。

```nginx
log_format self_format '$remote_addr - $http_user_agent	- $remote_addr'
                       '"$request" $status $body_bytes_sent '
                       '"$http_referer" "$http_user_agent" "$request_uri"';

access_log  logs/access.log self_format;
```

![image-20240530001709924](/nginx%E6%97%A5%E5%BF%97%E9%85%8D%E7%BD%AE/image-20240530001709924.png)

## 2.错误日志

错误日志主要记录服务器和请求处理过程中的错误信息，通过 error_log 实现。

错误日志在Nginx中是通过`error_log`指令实现的。该指令记录服务器和请求处理过程中的错误信息。

### 2.1 语法

```nginx
# 设置错误日志及错误级别
error_log file [level];
```

访问日志设置字段说明：

- error_log，关键字，不能修改。
- file：日志文件存放的路径。
- level：错误级别，常见的日志级别有 debug、info、notice、warn、error、crit、alert、merg，级别越高，记录的信息越少，默认为 error。

<font color='red'>注意：不要配置info等级较低的级别，会带来大量的磁盘I/O消耗。</font>

### 2.2 作用域

可以使用 error_log 日志的作用域有：main、http、server、loaction，如果在这几个作用域之外使用 error_log，Nginx 会报错。

### 2.3 基础使用

指定 error_log 的日志写入路径为 Nginx 目录下的 logs/error.log 文件。

```nginx
error_log logs/error.log;
```

指定 error_log 的日志写入路径为 Nginx 目录下的 logs/error.log 文件，日志级别为 info。

```nginx
error_log logs/error.log info;
```

### 2.4 错误日志配置测试

指定 error_log 的日志写入路径为 Nginx 目录下的 logs/error.log 文件，正常输出错误到 logs/error.log 中。

```nginx
error_log logs/error.log;
```

![image-20240530002927738](/nginx%E6%97%A5%E5%BF%97%E9%85%8D%E7%BD%AE/image-20240530002927738.png)

指定 error_log 的日志写入路径为 Nginx 目录下的 logs/error.log 文件，日志级别为 info。

```nginx
error_log logs/error.log info;
```

![image-20240530003115339](/nginx%E6%97%A5%E5%BF%97%E9%85%8D%E7%BD%AE/image-20240530003115339.png)