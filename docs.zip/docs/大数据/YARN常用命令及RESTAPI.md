---
title: YARN常用命令及Rest API
createTime: 2024/08/05 18:57:14
permalink: /article/yarn_rest_api/
tags:
  - Hadoop
  - YARN
---

# YARN

## 1.YARN常用命令

### 1.1 作业

| 命令                                                         | 说明                    |
| ------------------------------------------------------------ | ----------------------- |
| yarn application -list                                       | 列出所有的application   |
| yarn application -list -appStates [ALL、NEW、NEW_SAVING、SUBMITTED、ACCEPTED、RUNNING、FINISHED、FAILED、KILLED] | 根据application状态过滤 |
| yarn application -kill [applicationId]                       | Kill掉application       |

查看所有任务

```shell
yarn application -list
```

![image-20231030104820397](/yarn_rest_api/image-20231030104820397.png)

查看指定任务状态的作业


```sh
# state 可选的有：ALL、NEW、NEW_SAVING、SUBMITTED、ACCEPTED、RUNNING、FINISHED、FAILED、KILLED
yarn application -list -appStates <state>
# 示例
yarn application -list -appStates RUNNING,ACCEPTED
```

![image-20230412114200435](/yarn_rest_api/image-20230412114200435.png)

查看正在运行的任务信息

```shell
yarn applicationattempt -list <application_id>
```

![image-20231030105214173](/yarn_rest_api/image-20231030105214173.png)

结束作业

```shell
yarn application -kill <application_id>
```

### 1.2 日志

查询指定作业的日志

```shell
# 如果提示内存限制，可以在如下命令后，添加 --size -1
yarn logs -applicationId <application_id>
```

![image-20231030105613765](/yarn_rest_api/image-20231030105613765.png)

查询指定 Container 的日志

```shell
yarn logs -applicationId <application_id> -containerId <container_id>
```

### 1.3 Application Attempt

| 命令                                                   | 说明                          |
| ------------------------------------------------------ | ----------------------------- |
| yarn applicationattempt -list [ApplicationId]          | 列出所有Application尝试的列表 |
| yarn applicationattempt -status [ApplicationAttemptId] | 打印Application Attempt的状态 |

列出Application的所有尝试
```shell
yarn applicationattempt -list [ApplicationId]
```

![image-20240122102411843](/yarn_rest_api/image-20240122102411843.png)

打印Application Attempt的状态

```shell
yarn applicationattempt -status [ApplicationAttemptId]
```

![image-20240122102545463](/yarn_rest_api/image-20240122102545463.png)

### 1.4 容器

| 命令                                        | 说明                |
| ------------------------------------------- | ------------------- |
| yarn container -list [ApplicationAttemptId] | 列出所有的Container |
| yarn container -status [ContainerId]        | 打印Container状态   |

  列出所有的Container

```shell
yarn container -list [ApplicationAttemptId]
```

![image-20240122103049934](/yarn_rest_api/image-20240122103049934.png)

打印Container状态

```shell
yarn container -status [ContainerId]
```

![image-20240122103145929](/yarn_rest_api/image-20240122103145929.png)



### 1.5 其他

| 命令                           | 说明         |
| ------------------------------ | ------------ |
| yarn node -list -all           | 查看节点状态 |
| yarn rmadmin -refreshQueues    | 加载队列配置 |
| yarn queue -status [QueueName] | 打印队列信息 |

查看节点状态

```shell
yarn node -list -all
```

![image-20240122101045236](/yarn_rest_api/image-20240122101045236.png)

加载队列配置

```shell
# 需要在RM节点执行
yarn rmadmin -refreshQueues
```

![image-20240122101741713](/yarn_rest_api/image-20240122101741713.png)

查看队列状态

```shell
yarn queue -status [QueueName]
```

![image-20240122101841492](/yarn_rest_api/image-20240122101841492.png)

## 2.YARN Rest Api

YARN Rest Api文档地址：https://hadoop.apache.org/docs/stable/hadoop-yarn/hadoop-yarn-site/ResourceManagerRest.html

### 2.1 集群

**获取 RM 节点状态**

```sh
# URL
http://rm-http-address:port/ws/v1/cluster/info
# Method
GET
# 示例
curl -X GET -u e3base:'Sit@Paas&123' -i "http://172.21.9.101:13006/ws/v1/cluster/info"
# 注：如果集群集成了kerbeors，需要增加--negotiate参数
```

![image-20230810105526308](/yarn_rest_api/image-20230810105526308.png)

**获取集群Metrics**

```shell
# URL
http://rm-http-address:port/ws/v1/cluster/metrics
# Method
GET
# 示例
curl -X GET -u e3base:'Sit@Paas&123' -i "http://172.21.9.101:13006/ws/v1/cluster/metrics"
# 注：如果集群集成了kerbeors，需要增加--negotiate参数
```

![image-20230810110235599](/yarn_rest_api/image-20230810110235599.png)

### 2.2 队列

**获取集群队列**

```shell
# URL
http://rm-http-address:port/ws/v1/cluster/scheduler
# Method
GET
# 示例
curl -X GET -u e3base:'Sit@Paas&123' -i "http://172.21.9.101:13006/ws/v1/cluster/scheduler"
# 注：如果集群集成了kerbeors，需要增加--negotiate参数
```

![image-20230810110941722](/yarn_rest_api/image-20230810110941722.png)

### 2.3 作业

**获取集群作业**

```shell
# URL
http://rm-http-address:port/ws/v1/cluster/apps
# Method
GET
# 示例
curl -X GET -u e3base:'Sit@Paas&123' -i "http://172.21.9.101:13006/ws/v1/cluster/apps"
# 注：如果集群集成了kerbeors，需要增加--negotiate参数
```

![image-20230810111144989](/yarn_rest_api/image-20230810111144989.png)

## 3.其他

### 3.1 相关资源

1. YARN官方文档：https://hadoop.apache.org/docs/stable/
1. 大数据之Hadoop集群中YARN常用命令：https://www.cnblogs.com/sw-code/p/16387038.html