---
title: Kerberos 基础使用
createTime: 2024/08/05 18:57:14
permalink: /article/kerberos_base/
tags:
  - 大数据
  - kerberos
---

# `Kerberos` 基础使用

## 1. `Kerberos` 简介

`Kerberos` 是一种计算机网络安全认证协议，用于在不安全的网络上实现安全通信。它最初由麻省理工学院（`MIT`）开发，现已成为广泛使用的标准。`Kerberos` 协议主要用于客户端-服务器模型中，通过对称密钥密码学和第三方可信任机构（`Kerberos` 密钥分发中心，`KDC`）来实现安全认证。

### 1.1 `Kerberos` 的主要组件

1. `Key Distribution Center (KDC)`：
   - 负责管理和分发密钥，包括身份验证服务器（`AS`）和票据授予服务器（`TGS`）。
2. 客户端（`Client`）：
   - 请求认证和服务访问的用户或应用程序。
3. 服务服务器（`Service Server`）：
   - 提供具体服务的服务器，例如文件服务器、邮件服务器等。

### 1.2 `Kerberos` 的工作流程：

1. 身份验证（`Authentication Service`）：

   - 用户向 `KDC` 请求认证，提供用户名。
   - `KDC` 检查用户是否存在，并生成一个会话密钥和一个票据授予票据（`Ticket Granting Ticket`，`TGT`），然后使用用户的密码加密会话密钥和 `TGT`。

2. 票据授予（`Ticket Granting Service`）：

   - 用户解密 `TGT` 并使用它向 `KDC` 请求访问特定服务的票据。

   - `KDC` 验证 `TGT`，生成一个服务票据（`Service Ticket`），并发送给用户。

3. 服务访问：

   - 用户将服务票据发送给目标服务。
   - 服务验证票据，允许用户访问。

## 2. `Kerberos` 常用命令

### 2.1 `kadmin.local` 

> 说明：`kadmin.local` 的命令均需要在 `KDC` 节点进行

生成主体

```shell
kadmin.local -q "addprinc -randkey presto/admin@EXAMPLE.COM"
```

生成 `keytab` 文件

```shell
kadmin.local -q "xst -norandkey -k /euansu/presto.keytab presto/admin@EXAMPLE.COM"
```

`kadmin.local` 不指定 `-q` 则会直接进入交互环境，如下是修改管理员账号密码的示例

```shell
# 进入交互环境
kadmin.local
# 输入要修改的密码
change_password presto/admin@EXAMPLE.COM
```

![image-20240806152101547](/Kerberos%E5%9F%BA%E7%A1%80%E4%BD%BF%E7%94%A8/image-20240806152101547.png)

### 2.2 `kadmin`

> 说明：`kadmin` 命令能够在非 `KDC` 节点执行，通过指定管理员的主体实现主体、`keytab` 的生成



生成主体

```shell
kadmin -p ibdc/admin@EXAMPLE.COM -q "addprinc -randkey test@EXAMPLE.COM"
```

生成主体的 `keytab`
```shell
kadmin -p ibdc/admin@EXAMPLE.COM -q "ktadd -k /euansu/test.keytab test@EXAMPLE.COM"
```

### 2.3 常用命令

显示 `kerberos` 票据缓存

```shell
klist
```

客户端认证 `kerberos` 主体

```shell
kinit -kt /euansu/test.keytab test@EXAMPLE.COM
```

刷新票据

```shell
/usr/bin/kinit -R -c /tmp/krb5cc_1001
```

### 2.4 其他

使用 `curl` 的时候，指定 `--negotiate` 就能够携带 `kerberos` 票据请求远程服务

```
curl -X GET -H "Content-Type: application/json" -u euansu:euansu --negotiate -s "http://127.0.0.1:8006/jmx"
```

## 3.`kerberos` 常见问题

问题现象

```
[06/Apr/2024 18:16:59 +0800] kt_renewer   INFO     Reinitting kerberos retry attempt 0 from keytab /usr/bin/kinit -k -t /etc/security/keytabs/smokeuser.headless.keytab -c /tmp/krb5cc_1001 euansu@EXAMPLE.COM
[06/Apr/2024 18:17:00 +0800] kt_renewer   ERROR    Couldn't reinit from keytab! `kinit' exited with 1.

kinit: Keytab contains no suitable keys for euansu@EXAMPLE.COM while getting initial credentials
```

解决办法

```
# /etc/security/keytabs/smokeuser.headless.keytab，keytab文件不包含euansu@EXAMPLE.COM主体，如果找不到主体对应的keryab，重新执行认证流程的生成keytab操作
```

问题现象

```
[23/Mar/2024 17:09:17 +0800] kt_renewer   ERROR    Couldn't renew kerberos ticket in order to work around Kerberos 1.8.1 issue. Please check that the ticket for 'euansu@EXAMPLE.COM' is still renewable:
  $ klist -f -c /tmp/krb5cc_1001
If the 'renew until' date is the same as the 'valid starting' date, the ticket cannot be renewed. Please check your KDC configuration, and the ticket renewal policy (maxrenewlife) for the 'euansu@EXAMPLE.COM' and `krbtgt' principals.
```

解决办法

```
# 执行klist查看缓存的认证信息，如果管控平台使用的kerberos ticket无renew untill参数，执行如下命令后，重新kinit
sudo kadmin.local -q 'modprinc -maxrenewlife 365d euansu@EXAMPLE.COM"
```