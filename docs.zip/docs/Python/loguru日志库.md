---
title: loguru 日志库
createTime: 2024/09/13 10:57:38
permalink: /article/python_loguru/
tags:
  - Python
---
# loguru 日志库

## 安装loguru

```shell
pip install loguru -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 基本使用
loguru 提供了一个全局的logger，可以直接使用 logger 对象来记录日志
```python
from loguru import logger

logger.debug("这是一个调试消息")
logger.info("这是一个信息消息")
logger.warning("这是一个警告消息")
logger.error("这是一个错误消息")
logger.critical("这是一个严重错误消息")
```
执行如上代码,会直接在控制台输出日志信息.
![img.png](/python_loguru_static/img.png)

## 日志保存到文件
可以将日志输出到文件中,如下代码所示
```python
from loguru import logger

logger.add("file.log", rotation="500 MB")  # 当文件达到 500 MB 时自动创建新文件
logger.info("这条日志会保存到文件中")
```
![img.png](/python_loguru_static/img2.png)

还能够使用不同的参数自定义日志文件,例如:
- rotation: 自动轮换日志文件的条件,可以基于文件大小、时间等
- compression: 压缩日志文件的格式,例如 gzip、zip等
- retention: 保留多久的日志文件(基于时间或数量)

```python
from loguru import logger

logger.add("file_{time}.log", rotation="1 day", compression="zip", retention="10 days")
```
## 格式化日志输出
还能够自定义日志的输出格式，例如：
```python
from loguru import logger

logger.add("formate_log.log", format="{time} {level} {message}")
logger.info("这是一条格式化的日志")
```
执行如上代码,会在formate_log.log文件中输出如下日志信息
![img.png](/python_loguru_static/img3.png)
可用的占位符包括：
- {time}: 日志的时间戳 
- {level}: 日志级别（INFO、DEBUG、ERROR等） 
- {message}: 日志消息内容 
- {module}: 当前模块 
- {file}: 文件名 
- {line}: 行号

## 异常捕获
loguru 还可以自动捕获异常并记录详细的堆栈信息：
```python
from loguru import logger

def divide(a, b):
    return a / b

try:
    divide(1, 0)
except ZeroDivisionError:
    logger.exception("捕获了除零异常")
```
执行如上代码，会在控制台输出如下日志信息
![img.png](/python_loguru_static/img4.png)
日志文件中会输出如下信息
![img.png](/python_loguru_static/img5.png)

## Django项目中使用loguru

安装 `logurur`

```shell
pip install loguru -i https://pypi.tuna.tsinghua.edu.cn/simple
```

创建日志配置文件，`django` 并不支持直接配置 `loguru` 作为默认的日志处理模块，因此这里单独创建一个日志的配置文件 `logging_config.py` ，使用时导入该文件中的 `logger` 即可。

```python
from loguru import logger
import sys
import os

# 清除默认的 logger
logger.remove()

# 添加新的 handler
logger.add(sys.stderr, level="INFO", format="{time} {level} {message}", backtrace=True, diagnose=True)

# 添加文件日志
root_path = os.environ.get('PROJECT_HOME')
logger.add(f"{root_path}/logs/my_project.log", rotation="1 MB", retention="10 days", level="INFO", format="{time} {level} {message}")
```

在视图函数中使用 `loguru` 只需要导入 `logger` 对象，直接使用即可，如下所示：

```python
from djangoProject.logging_config import logger

def get_info(request):
    logger.trace("This is a trace message")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.success("This is a success message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
    ...
```

视图函数处理后，在日志文件中打印出如下内容：

![image-20241010172622327](/python_loguru_static/image-20241010172622327.png)