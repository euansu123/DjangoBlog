---
title: FastApi搭建部署
createTime: 2024/08/02 10:57:38
permalink: /article/fastapi_tutor/
tags:
  - Python
  - FastApi
---

# FastApi

FastApi 是一个现代、快速（高性能）的 web 框架，用于基于标准Python构建的API。

官方网址：https://fastapi.tiangolo.com/

## 1.安装

### 1.1 环境信息

```shell
# Python版本
3.8.0
```

### 1.2 安装 FastApi

```shell
pip install fastapi
# uvicorn 作为服务启动fastapi框架
pip install uvicorn
```

## 2.使用

```python
# 导入FastAPI第三方包
from fastapi import FastAPI
# 创建FastAPI对象
app = FastAPI()
# 路由地址
@app.get("/")
# 后端方法
def read_root():
    return {"Hello": "World"}
```

## 3.部署

### 3.1 Gunicorn

Gunicorn 是一个 unix 上被广泛使用的高性能 Python WSGI Unix Http Server，和大多数的 Web 框架兼容，并具有实现简单，轻量级，高性能的特点。

#### 3.1.1 安装 Gunicorn

```shell
pip install uvicorn
pip install gunicorn
```

#### 3.1.2 运行项目

##### 3.1.2.1 以配置文件的方式运行项目

**配置文件**

```python
# -*- coding=utf-8 -*-
import os

# 设置守护进程
daemon = True
# 监听内网端口
bind = '0.0.0.0:8000'
# 进程文件目录
pidfile = './gunicorn.pid'
chdir = './'
# 工作模式
worker_class='uvicorn.workers.UvicornWorker'
# 并行工作进程数
workers = 3
# 线程数
threads = 2
# 设置最大并发量
worker_connections = 1000
loglevel = 'debug'
access_log_format = '%(t)s %(p)s %(h)s "%(r)s %(s)s %(L)s %(b)s %(f)s"  "%(a)s"'
# 设置日志保存路径
log_dir = './log'
if not os.path.exists(log_dir):
    os.mkdir(log_dir)
accesslog = './log/gunicorn_access.log'
errorlog = './log/gunicorn_error.log'
```

**运行项目**

```shell
gunicorn main:app -c gunicorn.py
```

![image-20230801194758875](/FastApi%E6%A1%86%E6%9E%B6/image-20230801194758875.png)

![image-20230801194635059](/FastApi%E6%A1%86%E6%9E%B6/image-20230801194635059.png)

##### 3.1.2.2 直接运行项目

```shell
gunicorn main:app -b 0.0.0.0:8000 -w 4 -k uvicorn.workers.UvicornWorker --daemon
```

![image-20230801202803324](/FastApi%E6%A1%86%E6%9E%B6/image-20230801202803324.png)

![image-20230801202823890](/FastApi%E6%A1%86%E6%9E%B6/image-20230801202823890.png)