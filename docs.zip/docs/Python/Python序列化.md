---
title: Python 序列化
createTime: 2022/12/27 10:57:38
permalink: /article/python_serialization/
tags:
  - Python
---

## 序列化

序列化是指将对象转换成字节流，从而存储对象或将对象传输到内存、数据库或文件的过程，它的主要用途是保存对象的状态，以便能够在需要时重新创建对象，反向过程称为“反序列化”。

<!--more-->

### 序列化的工作原理

![serialization-process](/%E5%BA%8F%E5%88%97%E5%8C%96/serialization-process.jpg)

<center>序列化原理图</center>

对象杯序列化成流，其中不仅包含数据，还包含对象类型的相关信息，如版本、区域性和程序集名称。 可以将此流中的内容存储在数据库、文件或内存中。

### 序列化的用途

借助序列化，开发者可以保存对象的状态，并能在需要时重新创建对象，同时还能存储对象和交换数据。 通过序列化，开发者可以执行如下操作：通过 Web 服务将对象发送到远程应用程序、在域之间传递对象、以 XML 字符串的形式传递对象通过防火墙、跨应用程序维护安全性或用户专属信息。

### 序列化的代码实现

#### Pickle

Python提供了 `pickle` 模块来实现序列化。

```python
# coding=utf-8
import pickle
dic = {'name':'Bob','age':20, 'score':88}
# 序列化
s1 = pickle.dumps(dic)
print(s1)
# 反序列化
s2 = pickle.loads(s1)
print(s2)
```

执行代码输出的结果为：

```python
(dp0
S'age'
p1
I20
sS'score'
p2
I88
sS'name'
p3
S'Bob'
p4
s.
{'age': 20, 'score': 88, 'name': 'Bob'}
```

#### JSON

如果要在不同的编程语言之间传递对象，需要把对象序列化为标准格式，例如XML，但更好的方法是序列化为JSON格式，因为JSON就是一个字符串，可以被所有语言读取。

JSON与Python数据类型的对应关系如下所示：

| JSON类型   | Python类型 |
| :--------- | :--------- |
| {}         | dict       |
| []         | list       |
| "string"   | str        |
| 1234.56    | int或float |
| true/false | True/False |
| null       | None       |

```python
import json
dic = {'name':'Bob','age':20, 'score':88}
# 序列化
s1 = json.dumps(dic)
print(type(s1))
print(s1)
# 反序列化
s2 = json.loads(s1)
print(type(s2))
print(s2)
```

执行代码输出的结果为：

```python
<type 'str'>
{"age": 20, "score": 88, "name": "Bob"}
<type 'dict'>
{u'age': 20, u'score': 88, u'name': u'Bob'}
```

