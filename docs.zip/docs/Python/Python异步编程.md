---
title: Python异步编程
createTime: 2024/06/02 10:57:38
permalink: /article/python_async_base/
tags:
  - Python
---

# Python 异步编程

## 异步编程

![image-20240602153514464](//Python%E5%BC%82%E6%AD%A5%E7%BC%96%E7%A8%8B/image-20240602153514464.png)

异步编程是一种编程范式，通过非阻塞的方式执行任务，允许程序在等待某些操作（如I/O操作、网络请求、数据库查询等）完成时，继续执行其他任务。这与同步编程（或阻塞编程）形成对比，后者在等待操作完成时会阻塞执行流程，直到任务完成才继续执行。

以下是异步编程的一些关键概念和特点：

1. **非阻塞执行：** 在异步编程中，当一个任务需要等待某些操作完成时（例如等待网络请求的响应），程序不会停止执行其他任务，而是会继续处理其他任务。
2. **回调函数：** 异步编程经常使用回调函数，在等待操作完成后，这些回调函数会被执行，以处理操作的结果。回调函数允许程序在任务完成后继续执行相应的代码。
3. **Promise和Future：** 许多异步编程模型使用Promise或Future对象来表示将来某个时间点会完成的操作结果。Promise和Future提供了一种管理异步操作结果的方法，允许在结果可用时执行相应的代码。
4. **协程：** 协程是异步编程中常用的一种构造，允许函数在等待操作完成时暂停执行，并在操作完成后恢复执行。Python中的`async`和`await`关键字用于定义和控制协程。
5. **事件循环：** 异步编程依赖于事件循环来管理和调度异步任务。事件循环会不断检查和执行已完成的任务，并在任务完成后触发相应的回调或恢复协程的执行。

<font color='red'>说明：异步并不简单的等于并发，更精准的表述应该是并发，也即多个任务在同一时间段内交替运行，而不是同时运行。</font>

## asyncio 模块

`asyncio` 模块是用来编写 **并发** 代码的库，使用 `async/await` 语法。

`asyncio` 模块最大特点就是，只存在一个线程，与 JavaScript 中的 `async/await` 一样。

`asyncio` 模块在单线程上启动一个事件循环（event loop），时刻监听着新进入循环的事件，对事件进行处理，并不断地重复这个过程，直到异步任务结束。

![image-20240602154236494](/Python%E5%BC%82%E6%AD%A5%E7%BC%96%E7%A8%8B/image-20240602154236494-17173144729521.png)
## asyncio 模块示例

代码示例

```py
import asyncio

async def count():
    print("Start")
    await asyncio.sleep(1)
    print("End")

async def main():
    # gather()函数的作用是收集，能够按照协程的执行顺序保存对应协程的执行结果。
    await asyncio.gather(count(), count(), count())

# run()通常用于脚本或应用程序的入口点，用于启动异步操作。
asyncio.run(main())
```

执行示例

![image-20240602155343714](/Python%E5%BC%82%E6%AD%A5%E7%BC%96%E7%A8%8B/image-20240602155343714.png)

也即，异步操作能够在单线程的情况下，对协程依次执行，遇到阻塞的情况就会等待去执行下一个协程，并对协程的执行结果进行收集。

## FastApi 框架

`FastApi` 是一个用于构建 API 的现代、快速（高性能）的 web 框架，使用 Python 并基于标准的 Python 类型提示。

`FastApi` 能够支持异步编程的 `async/await` 语法。

如下是一个简单的代码示例，用户点餐，提供了可乐和汉堡，在制作汉堡的同时，餐厅人员也在制作可乐，而不是等待汉堡完成后再去制作可乐，如下是这个过程的模拟。

```python
import asyncio
from fastapi import FastAPI
from datetime import datetime

app = FastAPI()


async def get_coca(number: int):
    start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    await asyncio.sleep(number)
    end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return {"coca": number, "start": start, "end": end}


async def get_burgers(number: int):
    start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    await asyncio.sleep(number)
    end = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return {"burgers": number, "start": start, "end": end}

# 路由地址定义
@app.get("/orders")
async def read_orders(burgers: int = 0, coca: int = 0, consumer: str = ""):
    # 这里收集协程的处理结果
    result = await asyncio.gather(get_burgers(burgers), get_coca(coca))
    return {"consumer": consumer, "order": result}

```

接口测试结果：

![image-20240602165635258](/Python%E5%BC%82%E6%AD%A5%E7%BC%96%E7%A8%8B/image-20240602165635258.png)

如上就是 Python 异步编程的简单示例，主要是相关概念以及模块的使用介绍，如果有需要可以查询 `asyncio` 模块的官方文档，或者是 `FastAPI` 的官方文档，尤其是 `FastAPI` 官网关于 `async/await` 的章节使用汉堡做了详细的讲述。

## 参考资料

[1] 并发 async / await https://fastapi.tiangolo.com/zh/async/#_4

[2] Python异步编程入门 https://www.ruanyifeng.com/blog/2019/11/python-asyncio.html

[3] asyncio官方文档 https://docs.python.org/3/library/asyncio.html