---
title: Python中的正则表达式
createTime: 2024/03/11 10:57:38
permalink: /article/python_regular/
tags:
  - Python
---

# Python中的正则表达式

## 1.re模块使用入门

### 1.1 re.match 函数

函数定义:

re.match 尝试从字符串的起始位置匹配一个模式，如果不是起始位置匹配成功的话，match() 就返回 none。

函数语法:

```python
re.match(pattern, string, flags=0)
```

函数参数说明:

| 参数    | 描述                                                         |
| :------ | :----------------------------------------------------------- |
| pattern | 匹配的正则表达式                                             |
| string  | 要匹配的字符串。                                             |
| flags   | 标志位，用于控制正则表达式的匹配方式，如:是否区分大小写，多行匹配等等。 |

代码示例:

```python
# re.match()
print(re.match('www','www.euansu.cn'))
print(re.match('cn','www.euansu.cn'))
```

代码执行结果

![image-20240311215434209](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311215434209.png)

我们可以使用 group(num) 或 groups() 匹配对象函数来获取匹配表达式。

| 匹配对象方法 | 描述                                                         |
| :----------- | :----------------------------------------------------------- |
| group(num=0) | 匹配的整个表达式的字符串，group() 可以一次输入多个组号，在这种情况下它将返回一个包含那些组所对应值的元组。 |
| groups()     | 返回一个包含所有小组字符串的元组，从 1 到 所含的小组号。     |

代码示例:

```python
strs = "Cats are smarter than dogs"
res = re.match(r'(.*) are (.*?) .*', strs, re.M|re.I)
if res:
    print(res.group())
    print(res.group(1))
    print(res.group(2))
    print(res.groups())
```

代码执行结果:

![image-20240311215728593](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311215728593.png)

### 1.2 re.search 函数

函数定义:

re.search 扫描整个字符串并返回第一个成功的匹配。

函数语法:

```python
re.search(pattern, string, flags=0)
```

函数参数说明:

| 参数    | 描述                                                         |
| :------ | :----------------------------------------------------------- |
| pattern | 匹配的正则表达式                                             |
| string  | 要匹配的字符串。                                             |
| flags   | 标志位，用于控制正则表达式的匹配方式，如:是否区分大小写，多行匹配等等。 |

代码示例:

```python
print(re.search('www','www.euansu.cn'))
print(re.search('cn','www.euansu.cn'))
```

代码执行结果:

![image-20240311215908377](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311215908377.png)

我们可以使用 group(num) 或 groups() 匹配对象函数来获取匹配表达式。

| 匹配对象方法 | 描述                                                         |
| :----------- | :----------------------------------------------------------- |
| group(num=0) | 匹配的整个表达式的字符串，group() 可以一次输入多个组号，在这种情况下它将返回一个包含那些组所对应值的元组。 |
| groups()     | 返回一个包含所有小组字符串的元组，从 1 到 所含的小组号。     |

代码示例:

```python
strs = "Cats are smarter than dogs"
res = re.search(r'(.*) are (.*?) .*', strs, re.M|re.I)
if res:
    print(res.group())
    print(res.group(1))
    print(res.group(2))
    print(res.groups())
```

代码执行结果:

![image-20240311220002792](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220002792.png)

### 1.3 re.sub 函数

函数定义:

Python 的 re 模块提供了re.sub用于替换字符串中的匹配项。

函数语法:

```python
re.sub(pattern, repl, string, count=0, flags=0)
```

函数参数说明:

| 参数    | 描述                                                  |
| :------ | :---------------------------------------------------- |
| pattern | 匹配的正则表达式                                      |
| repl    | 替换的字符串，也可为一个函数。                        |
| string  | 要被查找替换的原始字符串。                            |
| count   | 模式匹配后替换的最大次数，默认 0 表示替换所有的匹配。 |

代码示例:

```python
phone = '2004-959-959'
# 删除字符串中非数字的内容
num = re.sub(r'\D',"",phone)
print(num)
```

代码执行结果:

![image-20240311220230112](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220230112.png)

repl，也即要替换的内容是一个函数:

```python
def double(matched):
    value = int(matched.group('value'))
    return str(value*2)
s = 'A23G4HFD567'
# (?P<value>\d+):匹配一个或多个数字
print(re.sub('(?P<value>\d+)',double,s))
```

代码执行结果:

![image-20240311220318547](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220318547.png)

### 1.4 re.compile 函数

函数定义:

compile 函数用于编译正则表达式，生成一个正则表达式（ Pattern ）对象，供 match() 和 search() 这两个函数使用。

函数语法:

```python
re.compile(pattern[, flags])
```

函数参数定义:

- **pattern** : 一个字符串形式的正则表达式
- **flags** : 可选，表示匹配模式，比如忽略大小写，多行模式等，具体参数为:
  1. **re.I** 忽略大小写
  2. **re.L** 表示特殊字符集 \w, \W, \b, \B, \s, \S 依赖于当前环境
  3. **re.M** 多行模式
  4. **re.S** 即为 **.** 并且包括换行符在内的任意字符（**.** 不包括换行符）
  5. **re.U** 表示特殊字符集 \w, \W, \b, \B, \d, \D, \s, \S 依赖于 Unicode 字符属性数据库
  6. **re.X** 为了增加可读性，忽略空格和 **#** 后面的注释

代码示例:

```python
pattern = re.compile(r'\d+') # 匹配至少一个数字
# match函数匹配
res = pattern.match('one12twothree34four')
print(res)
# match函数从指定的位置开始匹配
# 从e开始匹配
res = pattern.match('one12twothree34four',2,10)
print(res)
# 从1开始匹配
res = pattern.match('one12twothree34four',3,10)
print(res)
print(res.group(0))
print(res.start(0))
print(res.end(0))
print(res.span(0))
```

代码执行结果:

![image-20240311220529226](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220529226.png)

### 1.5 re.findall 函数

函数定义:

在字符串中找到正则表达式所匹配的所有子串，并返回一个列表，如果有多个匹配模式，则返回元组列表，如果没有找到匹配的，则返回空列表。

函数语法:

```python
findall(string[, pos[, endpos]])
```

函数参数定义:

- **string** : 待匹配的字符串。
- **pos** : 可选参数，指定字符串的起始位置，默认为 0。
- **endpos** : 可选参数，指定字符串的结束位置，默认为字符串的长度。

代码示例:

```python
pattern = re.compile(r'\d+')   # 查找数字
res = pattern.findall('euansu 123 google 456')
print(res)
res = pattern.findall('euansu 123 google 456',0,9)
print(res)
```

代码执行结果:

![image-20240311220702634](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220702634.png)

### 1.6 re.finditer 函数

函数定义:

和 findall 类似，在字符串中找到正则表达式所匹配的所有子串，并把它们作为一个迭代器返回。

函数语法:

```python
re.finditer(pattern, string, flags=0)
```

函数参数定义:

| 参数    | 描述                                                         |
| :------ | :----------------------------------------------------------- |
| pattern | 匹配的正则表达式                                             |
| string  | 要匹配的字符串。                                             |
| flags   | 标志位，用于控制正则表达式的匹配方式，如:是否区分大小写，多行匹配等等。 |

代码示例:

```python
res = re.finditer(r"\d+","12a32bc43jf3")
print(res)
for item in res:
    print(item)
    print(item.group())
```

代码执行结果:

![image-20240311220914463](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311220914463.png)

### 1.7 re.split 函数

函数定义:

split 方法按照能够匹配的子串将字符串分割后返回列表，它的使用形式如下:

函数语法:

```python
re.split(pattern, string[, maxsplit=0, flags=0])
```

函数参数定义:

| 参数     | 描述                                                         |
| :------- | :----------------------------------------------------------- |
| pattern  | 匹配的正则表达式                                             |
| string   | 要匹配的字符串。                                             |
| maxsplit | 分隔次数，maxsplit=1 分隔一次，默认为 0，不限制次数。        |
| flags    | 标志位，用于控制正则表达式的匹配方式，如:是否区分大小写，多行匹配等等。 |

代码示例:

```python
print(re.findall('\W+','euansu, euansu, euansu.'))
# \W+ 匹配非字母数字及下划线
print(re.split('\W+','euansu, euansu, euansu.'))
print(re.split('\W+','euansu, euansu, euansu.',1))
```

代码执行结果:

![image-20240311221046604](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311221046604.png)

## 2.贪婪模式与非贪婪模式

贪婪模式:在正则表达式中，*、+、?、{n}、{n,m} 等限定符默认都是贪婪模式的。也就是说，它们会尽可能多地匹配字符。

非贪婪模式:在限定符后面加上 `?` 可以使其变为非贪婪模式。非贪婪模式会尽可能少地匹配字符。

代码示例:

```python
# 以下的*和+都是贪婪模式的匹配
# *
print(re.match('\d*','13012345678sa'))
# +
print(re.match('\d+','13012345678sa'))
# 以下的？则是非贪婪模式
# ?
print(re.match('\d?','13012345678'))
```

代码执行结果:

![image-20240311221307573](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311221307573.png)

数量匹配:匹配指定数量的字符，注意当指定的数量无上限的时候，也是贪婪模式。

代码示例:

```python
# {m} 匹配出现的m个字符
print(re.match('\d{3}','130123456789')) # 结果 130
# {m,} 匹配出现的m以上的字符
print(re.match('\d{3,}','130123456789')) # 结果 130123456789
# {m,n} 匹配出现的[3,5]之间的字符
print(re.match('\d{3,5}','130123456789')) # 结果 13012
```

代码执行结果:

![image-20240311221354068](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311221354068.png)

## 3.正则表达式的修饰符

正则表达式可以包含一些可选标志修饰符来控制匹配的模式。修饰符被指定为一个可选的标志。多个标志可以通过按位 OR(|) 它们来指定。

| 修饰符 | 描述                                                         |
| :----- | :----------------------------------------------------------- |
| re.I   | 使匹配对大小写不敏感                                         |
| re.L   | 做本地化识别（locale-aware）匹配                             |
| re.M   | 多行匹配，影响 ^ 和 $                                        |
| re.S   | 使 . 匹配包括换行在内的所有字符                              |
| re.U   | 根据Unicode字符集解析字符。这个标志影响 \w, \W, \b, \B.      |
| re.X   | 该标志通过给予你更灵活的格式以便你将正则表达式写得更易于理解。 |

代码示例:

```python
print(re.match('www','WWW.EUANSU.CN'))
print(re.match('www','WWW.EUANSU.CN',re.I|re.U))
```

代码执行结果:

![image-20240311221757670](/Python%E4%B8%AD%E7%9A%84%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/image-20240311221757670.png)

## 4.正则表达式的语法

| 模式        | 描述                                                         |
| :---------- | :----------------------------------------------------------- |
| ^           | 匹配字符串的开头                                             |
| $           | 匹配字符串的末尾。                                           |
| .           | 匹配任意字符，除了换行符，当re.DOTALL标记被指定时，则可以匹配包括换行符的任意字符。 |
| [...]       | 用来表示一组字符,单独列出:[amk] 匹配 'a'，'m'或'k'          |
| [^...]      | 不在[]中的字符:[^abc] 匹配除了a,b,c之外的字符。             |
| re*         | 匹配0个或多个的表达式。                                      |
| re+         | 匹配1个或多个的表达式。                                      |
| re?         | 匹配0个或1个由前面的正则表达式定义的片段，非贪婪方式         |
| re{ `n`}      | 精确匹配 `n` 个前面表达式。例如， **o{2}** 不能匹配 "Bob" 中的 "o"，但是能匹配 "food" 中的两个 o。 |
| re{ `n`,}     | 匹配 `n` 个前面表达式。例如， o{2,} 不能匹配"Bob"中的"o"，但能匹配 "foooood"中的所有 o。"o{1,}" 等价于 "o+"。"o{0,}" 则等价于 "o*"。 |
| re{ `n`, `m`}   | 匹配 `n` 到 m 次由前面的正则表达式定义的片段，贪婪方式         |
| a\| b       | 匹配a或b                                                     |
| (re)        | 对正则表达式分组并记住匹配的文本                             |
| (?imx)      | 正则表达式包含三种可选标志:i, m, 或 x 。只影响括号中的区域。 |
| (?-imx)     | 正则表达式关闭 i, m, 或 x 可选标志。只影响括号中的区域。     |
| (?: re)     | 类似 (...), 但是不表示一个组                                 |
| (?imx: re)  | 在括号中使用i, m, 或 x 可选标志                              |
| (?-imx: re) | 在括号中不使用i, m, 或 x 可选标志                            |
| (?#...)     | 注释.                                                        |
| (?= re)     | 前向肯定界定符。如果所含正则表达式，以 ... 表示，在当前位置成功匹配时成功，否则失败。但一旦所含表达式已经尝试，匹配引擎根本没有提高；模式的剩余部分还要尝试界定符的右边。 |
| (?! re)     | 前向否定界定符。与肯定界定符相反；当所含表达式不能在字符串当前位置匹配时成功 |
| (?> re)     | 匹配的独立模式，省去回溯。                                   |
| \w          | 匹配字母数字及下划线                                         |
| \W          | 匹配非字母数字及下划线                                       |
| \s          | 匹配任意空白字符，等价于 **[ \t\n\r\f]**。                   |
| \S          | 匹配任意非空字符                                             |
| \d          | 匹配任意数字，等价于 [0-9].                                  |
| \D          | 匹配任意非数字                                               |
| \A          | 匹配字符串开始                                               |
| \Z          | 匹配字符串结束，如果是存在换行，只匹配到换行前的结束字符串。 |
| \z          | 匹配字符串结束                                               |
| \G          | 匹配最后匹配完成的位置。                                     |
| \b          | 匹配一个单词边界，也就是指单词和空格间的位置。例如， 'er\b' 可以匹配"never" 中的 'er'，但不能匹配 "verb" 中的 'er'。 |
| \B          | 匹配非单词边界。'er\B' 能匹配 "verb" 中的 'er'，但不能匹配 "never" 中的 'er'。 |
| \n, \t, 等. | 匹配一个换行符。匹配一个制表符。等                           |
| \1...\9     | 匹配第n个分组的内容。                                        |
| \10         | 匹配第n个分组的内容，如果它经匹配。否则指的是八进制字符码的表达式。 |