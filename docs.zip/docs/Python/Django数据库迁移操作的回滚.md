---
title: Django 数据库迁移操作的回滚
createTime: 2022/07/21 19:10:38
permalink: /article/django_migrate_cancel/
tags:
  - Python
  - Django
---

Django 数据库的迁移通过 `makemigrations` 和 `migrate` 命令实现，其中 `makemigrations` 基于 `models.py` 的变更生成新的 `migrations` 文件， `migrate` 把 `migrations`文件应用到数据库，也可以取消已应用的 `migrations` 文件。

<!--more-->

# Django 的数据库迁移操作

1. 在 app 目录下的 models.py 文件中新增 class。

   ![Snipaste_2022-07-21_19-00-48](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-00-48.png)

2. 执行 `makemigrations` 命令生成迁移文件。

   ![Snipaste_2022-07-21_19-01-42](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-01-42.png)

3. 使用 `migrate` 应用迁移文件。

   ![Snipaste_2022-07-21_19-01-53](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-01-53.png)

   Django 迁移数据库后，会在 django_migrations 表中做记录，查询该表发现应用 myblog 最新的迁移 0002_test 已经被应用。

   ![Snipaste_2022-07-21_19-03-52](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-03-52.png)

# 使用 migrate 命令实现数据迁移的回滚

## 使用 migrate 回滚最近一次迁移操作

应用 myblog 共有两次迁移操作，分别是：0001_initial和0002_test，使用 `migrate` 命令指定应用 `myblog` 以及 `0001`。

```shell
python manage.py migrate myblog 0001
```

![Snipaste_2022-07-21_19-05-03](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-05-03.png)

命令执行成功后，查询 django_migrations 表的记录，此时数据库表中仅有 `0001` 的记录，迁移回滚操作成功。

![Snipaste_2022-07-21_19-05-28](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-05-28.png)

## 使用 migrate 回滚应用所有的迁移操作

执行 `makemigrations`和 `migrate` 命令，执行数据库的迁移操作。

![Snipaste_2022-07-21_19-06-39](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-06-39.png)

执行完成后，django_migrations 表出现 `0002` 迁移的记录。

![Snipaste_2022-07-21_19-07-15](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-07-15.png)

使用 migrate 命令指定应用 myblog ，并指定要回滚的操作为 zero。

```shell
python manage.py migrate zero
```

![Snipaste_2022-07-21_19-08-05](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-08-05.png)

查看 django_migrations 表，无应用 myblog 的迁移记录，数据库迁移回滚操作成功。 

![Snipaste_2022-07-21_19-08-15](/Django%E6%95%B0%E6%8D%AE%E5%BA%93%E8%BF%81%E7%A7%BB%E6%93%8D%E4%BD%9C%E7%9A%84%E5%9B%9E%E6%BB%9A/Snipaste_2022-07-21_19-08-15.png)





