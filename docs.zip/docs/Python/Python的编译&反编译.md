---
title: Python 的编译&反编译
createTime: 2024/07/23 10:57:38
permalink: /article/python_compile/
tags:
  - Python
---

# Python 的编译&反编译

## Python 的文件后缀

`Python` 常见的文件后缀有：`py`、`pyc`、`pyc`、`pyi`、`pyw`、`pyd`、`pyx` 等。

- `py`，`Python` 源代码文件，使用 `python xxx.py` 即可执行源码文件。
- `pyc`，`Python` 源代码编译生成的文件，由 `Python` 的虚拟机执行，相对于 `.py` 文件来说，`.pyc` 只是模块加载速度提高，并没有提高代码的执行速度，更多的意义在于避免源码的泄露。
- `pyo`，优化后的 `Python` 字节码缓存文件，`pyo` 文件和 `pyc` 文件基本上没有区别，唯一的优化是去掉了断言语句，即 `assert` 语句。
- `pyi`，`Python` 的存根文件，用于代码检查时的类型提示。
- `pyw`，`Python` 源文件的一种，一般只存在于 `Windows` 系统。
- `pyd`，`Python` 可直接调用的 `C` 语言动态链接库文件，一般只存在于 `Windows` 系统。
- `pyx`，`Cython` 源代码文件，一般用来编写 `Python` 的 `C` 扩展。

## Python 的编译和反编译

`Python` 的编译指的是将 `py` 文件编译为 `pyc` 文件，反编译则为该操作的逆向动作。

### Python 源文件的编译

`Python` 的编译共有以下三种方式：

1. 使用 `python xxx.py` 执行文件的过程中进行编译。

   首先准备一个简单的 `python` 文件 `hello.py`，内容如下：

   ```python
   # hello.py
   print("hello world")
   ```

   使用 `python hello.py`，执行该文件并没有生成 `pyc` 文件。

   ![image-20240723150130873](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723150130873.png)

   再创建一个 `import.py` 的文件，内容如下：

   ```python
   # import.py
   import hello
   ```

   使用 `python import.py`，执行该文件的时候，生成了 `pyc` 文件，`python3` 执行代码，会在当前目录下创建 `__pycache__` 目录下生成对应的 `pyc` 文件。

   ![image-20240723150552632](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723150552632.png)

   使用 `python` 可以直接执行该 `pyc` 文件，与执行 `python import.py` 的效果一致。

   ![image-20240723150704198](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723150704198.png)

2. 使用 `py_compile` 第三方库编译源文件。

   执行该步骤之前，先删除上一步操作生成的 `__pycache__` 这个目录，这一步操作是执行 `Python` 代码进行的编译操作，进行转化的代码参考如下内容，使用第三方库进行编译，无需考虑代码中是否包含 `import` 语句，均能够正常编译，如下所示：

   ```python
   import py_compile
   py_compile.compile('sample.py')
   ```

   ![image-20240723151100724](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723151100724.png)

   这里也可以使用 `python -m` 指定 `py_compile` 第三方库对文件进行编译。

   ![image-20240723151411059](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723151411059.png)

3. 使用 `compileall` 第三方库编译源文件。

   执行该步骤之前，先删除上一步操作生成的 `__pycache__` 这个目录，进行编译的操作与 `py_compile` 基本类似，不同的是 `compileall` 能够对文件进行迭代编译，进行编译操作的代码如下所示：

   ```python
   import compileall
   compileall.compile_file('hello.py')
   # 可以递归编译文件夹下所有的python源代码文件
   compileall.compile_dir('dir/', force=True)
   ```

   ![image-20240723153644351](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723153644351.png)

   执行完成如上代码后，在当前目录以及 `dir` 目录下生成对应的文件编译的 `pyc` 文件，直接进行执行，如下所示：

   ![image-20240723153838579](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723153838579.png)

   这里和 `py_compile` 一样，也能够直接指定文件进行编译，如下所示：

   ```python
   python -m compileall .\hello.py
   python -m compileall .\dir\
   ```

   ![image-20240723154043645](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723154043645.png)

### Python 的反编译

编译能够在一定程度上实现隐藏源代码的效果，可以通过反编译 `pyc` 文件来获取 `py` 源代码，这里使用 `uncompyle6` 第三方库，具体的过程如下：

1. 安装 `uncompyle6` 第三方库。

   ```shell
   pip install uncompyle6 -i https://pypi.tuna.tsinghua.edu.cn/simple
   ```

2. 使用 `uncompyle6` 对 `pyc` 文件进行反编译。

   ```shell
   uncompyle6 -o . *.pyc
   ```

   ![image-20240723155240907](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723155240907.png)

3. 打开生成的 `py` 源代码，内容如下，包含有 `Python` 版本信息、`uncompyle6` 版本信息，以及源代码内容。

   ![image-20240723155331593](/Python%E7%9A%84%E7%BC%96%E8%AF%91&%E5%8F%8D%E7%BC%96%E8%AF%91/image-20240723155331593.png)