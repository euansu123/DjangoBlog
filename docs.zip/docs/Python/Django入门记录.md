---
title: Django入门记录
createTime: 2022/07/25 11:57:38
permalink: /article/django_quick_start/
tags:
  - Python
  - Django
---

# 环境说明

```shell
# python 	3.7.8
# django 	2.1
# mysql 	5.7.36
```

<!--more-->

# Django 安装

```shell
# 使用pip命令时-i指定国内源地址，例如:
pip install -i https://pypi.mirrors.ustc.edu.cn/simple/ django==2.1
# django==2.1指定下载2.1版本的django
```

![image-20220725155753155](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725155753155.png)

# 创建 Django 项目

## 创建 Django 项目结构

```shell
# 创建django项目的目录，执行django-admin startproject xxx创建项目，例如：
django-admin startproject mysite
```

![image-20220725160232697](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725160232697.png)

## 创建 APP

每个 Django 项目中可以创建多个子应用（APP），每个子应用之间结构相互独立，共享项目资源。

```shell
# 执行如下命令创建APP
python manage.py startapp login
```

![image-20220725213601350](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725213601350.png)

## 编写路由

这里的路由是浏览器输入的 url 路径，经由 Django 服务器响应解析后进行转发，Django 的路由都写在 urls.py 文件中，urls.py 编写方法如下：

![image-20220725214129416](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725214129416.png)

## 编写视图函数

Django 路由转发给是凸函数进行处理，视图函数也即用来处理业务逻辑的方法，一般写在 views.py 文件中，views.py 编写方法如下：

![image-20220725214144549](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725214144549.png)

注意：

- 视图函数的参数 request 不能更改，因为 Django 使用 request 封装了网络请求的所有内容。
- return 不能直接返回字符串，必须由 HttpResponse 封装后，才可以被 Http 协议识别，也可使用 JsonResponse 封装后返回。

# 运行 Django 项目

```shell
# 使用python运行Django项目中的manage.py文件
# 执行该步时，需要进入项目目录中
python manage.py runserver [127.0.0.1:9000]
```

![image-20220725214431673](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725214431673.png)

直接访问 127.0.0.1:9000 ，页面显示为 not found，这是因为我们没有编写执行 / 的路由，所以 Django 无法对 127.0.0.1:9000 进行处理。

![image-20220725214541890](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725214541890.png)

加上编写的 /index/ 路由访问，就能够查看刚才所编写的视图函数返回的结果，至此，一个简单的 Django 项目就启动成功了。

![image-20220725214701611](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220725214701611.png)

# 返回 HTML 页面

创建 templates 目录用于存放 HTML 文件：

```
└── mysite
   ├── login
   ├── manage.py
   ├── mysite
   └── templates
```

在 settings.py 修改 TEMPLATES 中的 `DIRS ` 配置，`DIRS` 中定义了模板目录列表，Django 会在这些目录中寻找对应的 HTML 页面。

```python
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR,'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
```

在 templates 目录下编写 HTML 文件。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>test</title>
</head>
<body>
    <h1 style="background-color: antiquewhite;color: black">Hello Django!</h1>
</body>
</html>
```

修改对应的视图函数。

```python
def index(request):
    return render(request, 'index.html')
```

页面访问，出现 HTML 页面的响应。

![image-20220726110327707](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220726110327707.png)

# 使用静态文件

创建 static 目录用以存放静态文件：

```
└── mysite
   ├── db.sqlite3
   ├── login
   ├── manage.py
   ├── mysite
   ├── static
   └── templates
```

在 settings.py 新增静态文件的配置路径，`STATICFILES_DIRS` 中定义了静态文件的目录列表，Django 会在这些目录中寻找对应的静态文件。

```python
STATIC_URL = '/static/'

STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'static')
]
```

这里的 STATIC_URL 指的是在浏览器中访问静态文件的前缀配置，在 static 目录中存放一个 icon.jpg ，访问 localhost:8000/static/icon.jpg 即可查看图片。

![image-20220727203552955](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727203552955.png)

在 static 目录中新增 first.js 文件。

```javascript
function clickFuc(){
    alert('JS文件的响应！')
}
```

在上方所创建的 index.html 中引入 first.js，并引用 clickFuc 方法。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>test</title>
</head>
<body>
    <h1 style="background-color: antiquewhite;color: black">Hello Django!</h1>
    <button onclick="clickFuc()">点击</button>
    <script type="text/javascript" src="../static/first.js"></script>
</body>
</html>
```

访问 localhost:8000/index/，点击按钮就能够看到 JS 文件中方法的响应。

![image-20220727205316230](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727205316230.png)

# 接收页面输入的数据

修改 index.html 文件，使得能够通过页面输入数据。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
</head>
<body>
    <h1>用户输入：</h1>
    <form action="/index/" method="post">
        用户名：<input type="text" name="username" /><br />
        密码：&nbsp;&nbsp;&nbsp;&nbsp;<input type="password" name="password" /><br />
        <input type="submit" value="提交" />
    </form>
</body>
</html>
```

![image-20220727213805389](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727213805389.png)

修改视图函数。

```python
def index(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
    return render(request, 'index.html')
```

回到前端页面输入用户名和密码时，显示CSRF 跨域问题，这是因为 Django 的跨站请求保护机制，在 HTML 文件中加入一行 `{% csrf_token %}`。

![image-20220727210142361](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727210142361.png)

![image-20220727210557462](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727210557462.png)

刷新页面后，在页面再次输入，后端即可接收到来自前端的数据。

![image-20220727210420694](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727210420694.png)

# 返回动态页面

修改 index.html ，使之能够接收来自 Django 服务器处理后的数据。

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
</head>
<body>
    <h1>用户输入：</h1>
    <form action="/index/" method="post">
        {% csrf_token %}
        用户名：<input type="text" name="username" /><br />
        密码：&nbsp;&nbsp;&nbsp;<input type="password" name="password" /><br />
        <input type="submit" value="提交" />
    </form>

    <h1>用户展示：</h1>
        <table border="1">
            <thead>
                <tr>用户名</tr>
                <tr>密码</tr>
            </thead>
            <tbody>
                {% for item in data %}
                <tr>
                    <td>{{ item.user }}</td>
                    <td>{{ item.password }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
</body>
</html>
```

修改对应的视图函数。

```python
def index(request):
    user_list = []
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        temp = {'user': username, 'password': password}
        user_list.append(temp)
    return render(request, 'index.html', {'data': user_list})
```

在页面输入用户名和密码，就能够在下方的表格中进行展示。

![image-20220727211042579](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727211042579.png)

# 使用数据库

在 settings.py 中的 `INSTALLED_APPS` 中加入创建的应用。

```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'login'
]
```

在 settings.py 中的 `DATABASES` 配置数据库，这里 Django 配置了 sqlite 数据库暂时不做修改。

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}
```

编辑 login 应用下的 models.py 文件。

```python
class UserInfo(models.Model):
    user = models.CharField(max_length=32)
    password = models.CharField(max_length=32)
```

在终端执行数据库迁移命令。

```python
# 生成迁移文件
python.exe .\manage.py makemigrations
# 应用迁移文件到数据库生成库表
python.exe .\manage.py migrate
```

![image-20220727212039315](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727212039315.png)

修改视图函数从数据库读写数据。

```python
def index(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        # 将数据保存到数据库
        UserInfo.objects.create(user=username, password=password)

    # 从数据库中读取所有数据，注意缩进
    user_list = UserInfo.objects.all()
    return render(request, 'index.html', {'data': user_list})
```

即使再次刷新页面，也不会出现上面数据消失的情况，也即实现了数据的持久化操作。

![image-20220727212449288](/Django%E5%85%A5%E9%97%A8%E8%AE%B0%E5%BD%95/image-20220727212449288.png)
