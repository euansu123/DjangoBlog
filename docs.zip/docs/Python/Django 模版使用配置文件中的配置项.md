---
title: Django 模版使用配置文件中的配置项
createTime: 2025/05/14 12:57:38
permalink: /article/django_context_processors/
tags:
  - Python
  - Django
---

# Django 模版使用配置文件中的配置项

Django 的模版系统默认不暴露 `settings`，如果需要在模版中使用配置项有两种方式来实现，一种是通过视图传递过去，另一种则是通过上下文处理器 `context_processors` 进行传递，第一种适用于视图单一的情况，如果要修改的 `base.html` 这种基础的视图就不太适用，这里对上下文处理器的使用做一下记录。

首先是在项目路径下创建一个上下文管理器的文件，这里直接命名为 `context_processors.py`，编写获取配置的方法 `site_settings`，代码如下所示：

```python
#context_processors
from django.conf import settings

def site_settings(request):
    return {
        'SITE_NAME': settings.SITE_NAME,
    }
```

接下来需要注册上下文方法到模版的 `context_processors `中，修改 `settings.py` 文件中 `TEMPLATES` 的配置信息，如下所示

```python
# settings.py
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'DjangoBlog.context_processors.site_settings' # 这里要注意模版方法的引用
            ],
        },
    },
]
```

接下来是在模版中使用注册的上下文变量，其中变量的名称就是上下文管理器返回字典的键，如下所示

```html
<a href="/article/list/" class="nav-link px-2 link-secondary">{{ SITE_NAME }}</a>
```

实现效果如下图所示

![image-20250514104645924](/Django%20模版使用配置文件中的配置项/image-20250514104645924.png)