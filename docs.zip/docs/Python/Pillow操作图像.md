---
title: Pillow操作图像
createTime: 2024/04/20 10:57:38
permalink: /article/python_pillow/
tags:
  - Python
  - Pillow
---

# `Pillow` 操作图像

`Pillow` 是 `Jeffrey A.Clark` 及其贡献者开发的友好 `PIL` 分支，`PIL` 是 `Fredrik Lundh` 及其贡献者开发的 `Python` 图像库，使用如下命令即可安装 `Pillow` 库。

```shell
pip install Pillow -i https://pypi.tuna.tsinghua.edu.cn/simple
```

## 1.打开图像

要操作图像首先需要将图像加载到内存中，使用 `show()` 展示当前加载的图像，并打印图像的属性信息。

```python
from PIL import Image

# 打开一个图像文件
image = Image.open("messi.jpg")

# 打印图像的属性信息
print("image format:{}",image.format)
print("image size:{}",image.size)
print("image mode:{}",image.mode)

# 显示图像
image.show()
```

![image-20240820232840230](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820232840230.png)

打开的图像文件。

![image-20240820232901486](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820232901486.png)

## 2.调整图像大小

可以缩放图像到指定的尺寸。

```python
from PIL import Image

# 打开一个图像文件
image = Image.open("messi.jpg")

# 调整图像大小
resized_image = image.resize((800, 450))

# 显示调整后的图像
resized_image.show()
```

![image-20240820233404467](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820233404467.png)

## 3.旋转和翻转图像



```python
from PIL import Image

# 打开一个图像文件
image = Image.open("messi.jpg")

# 旋转图像（顺时针旋转 45 度）
rotated_image = image.rotate(45)

# 水平翻转图像
flipped_image = image.transpose(Image.FLIP_LEFT_RIGHT)

# 显示旋转和翻转后的图像
rotated_image.show()
flipped_image.show()
```

顺时针旋转 45 度的图像。

![image-20240820233655268](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820233655268.png)

水平翻转的图像。

![image-20240820233710510](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820233710510.png)

## 4.图像格式转换

这里可选择的格式有：

- `1`，二值化模式（1-bit 像素，黑和白）
- `L`，灰度模式（8-bit 像素，黑白）
- `P`，调色板模式（8-bit 像素，使用调色板映射到任何其他模式）
- `RGB`，彩色模式（3x8-bit 像素，真彩）
- `RGBA`， 带透明度的彩色模式（4x8-bit 像素，真彩 + 透明度）
- `CMYK`，印刷模式（4x8-bit 像素）
- `YCbCr`，亮度/色度模式（3x8-bit 像素）
- `LAB`，CIE Lab 颜色空间
- `HSV`，色调/饱和度/亮度模式
- `I`，32 位整型像素
- `F`，32 位浮点型像素

```python
from PIL import Image

# 打开一个图像文件
image = Image.open("messi.jpg")

# 将图像转换为调色板模式
gray_image = image.convert("P")

# 显示灰度图像
gray_image.show()
```

![image-20240820234536071](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820234536071.png)

## 5.图像保存

处理后的图像可以保存为新文件：

```
gray_image.save("new.jpg")
```

## 6.图像滤镜

Pillow 提供了多种滤镜，可以应用于图像，例如模糊、锐化等，有如下选项。

- `ImageFilter.BLUR`，模糊滤镜
- `ImageFilter.CONTOUR`，轮廓滤镜
- `ImageFilter.DETAIL`，细节增强滤镜
- `ImageFilter.EDGE_ENHANCE`，边缘增强滤镜
- `ImageFilter.EDGE_ENHANCE_MORE`，更强的边缘增强滤镜
- `ImageFilter.EMBOSS`，浮雕滤镜
- `ImageFilter.FIND_EDGES`，边缘检测滤镜
- `ImageFilter.SHARPEN`，锐化滤镜
- `ImageFilter.SMOOTH`，平滑滤镜
- `ImageFilter.SMOOTH_MORE`，更强的平滑滤镜
- `ImageFilter.GaussianBlur(radius=2)`，高斯模糊滤镜
- `ImageFilter.UnsharpMask(radius=2, percent=150, threshold=3)`，非锐化掩模
- `ImageFilter.MaxFilter(size=3)`，最大滤镜
- `ImageFilter.MinFilter(size=3)`，最小滤镜
- `ImageFilter.MedianFilter(size=3)`，中值滤镜
- `ImageFilter.ModeFilter(size=3)`，模式滤镜

```python
from PIL import ImageFilter, Image

# 打开一个图像文件
image = Image.open("messi.jpg")

# 应用模糊滤镜
blurred_image = image.filter(ImageFilter.BLUR)

# 显示模糊后的图像
blurred_image.show()
```

![image-20240820234830647](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820234830647.png)

## 7.绘制和添加文本

在图像上绘制形状或添加文本，需要使用 `ImageDraw` 模块：

```python
from PIL import ImageDraw, ImageFont

# 打开一个图像
image = Image.open("messi.jpg")

# 创建一个 ImageDraw 对象
draw = ImageDraw.Draw(image)

# 定义要绘制的文本及其位置
text = "GOAT, MESSI!"
position = (700, 400)

# 定义字体和大小 (这里需要一个 ttf 字体文件)
font = ImageFont.truetype("arial.ttf", 40)

# 绘制文本
draw.text(position, text, fill="white", font=font)

# 显示带文本的图像
image.show()
```

![image-20240820235514072](/Pillow%E6%93%8D%E4%BD%9C%E5%9B%BE%E5%83%8F/image-20240820235514072.png)
