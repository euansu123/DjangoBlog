---
title: Tkinter 实现一个计算器
createTime: 2024/07/19 10:57:38
permalink: /article/Tkinter_calculator/
tags:
  - Python
  - Tkinter
---

# `Tkinter` 开发计算器

## `Tkinter` 简介

`Tkinter` 是Python自带的标准 `GUI` 库，不需要单独安装，`TKinter` 支持跨平台运行，不仅可以在 `Windows` 上运行，还支持在 `Linux` 和 `Mac` 上运行，可以较为简单的实现工具类图形化界面，较为复杂的界面需要评估 `TKinter` 是否能够实现。

## 计算器的实现

实现思路

1. 首先是图形化界面的实现，这里可以使用 `Tkinter` 的布局，可以参考 `https://docs.zhengxinonly.com/python/03.tkinter/01.intro/02-pack.html` 这篇文档，最终选用了 `place` 这个自由度较高的组件。
2. 计算能力使用 `eval` 直接计算输入的表达式。

计算器图形化界面的实现

```python
from tkinter import *
from tkinter.ttk import *


class Calculator(Tk):
    def __init__(self):
        # 继承TK组件
        super().__init__()

        self.title("计算器")
        self.geometry("400x500")
        # 计算结果展示
        self.equation = StringVar()
        self.create_widgets()

    def create_widgets(self):
        """计算器的输入"""
        # 结果显示
        entry = Entry(self, textvariable=self.equation, width=16, font=('Times New Roman', 30, 'bold'))
        # entry.grid(row=0, column=0, columnspan=4)
        entry.place(relheight=0.2, relwidth=1, relx=0, rely=0)

        # 按钮
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]
        # 按键布局
        row, col = 1, 0
        for button in buttons:
            action = lambda x=button: self.on_button_click(x)
            calculator_button = Button(self, text=button, command=action)
            # calculator_button.grid(row=row, column=col)
            # 调整为place布局
            calculator_button.place(relheight=0.2, relwidth=0.25, relx=0.25 * col, rely=0.2 * row)

            col += 1
            if col > 3:
                col = 0
                row += 1

if __name__ == "__main__":
    calculator = Calculator()
    calculator.mainloop()
```

![image-20240719122341015](/Tkinter%E5%BC%80%E5%8F%91%E8%AE%A1%E7%AE%97%E5%99%A8/image-20240719122341015.png)

计算能力代码实现

```python
# 这里读取输入的内容进行计算
def on_button_click(self, char):
    """结果计算"""
    if char == '=':
        try:
            result = str(eval(self.equation.get()))
            self.equation.set(result)
            except:
                self.equation.set("输入错误")
            else:
                current_text = self.equation.get()
                new_text = current_text + char
                self.equation.set(new_text)
```

完整代码

```python
from tkinter import *
from tkinter.ttk import *


class Calculator(Tk):
    def __init__(self):
        # 继承TK组件
        super().__init__()

        self.title("计算器")
        self.geometry("400x500")
        # 计算结果展示
        self.equation = StringVar()
        self.create_widgets()

    def create_widgets(self):
        """计算器的输入"""
        # 结果显示
        entry = Entry(self, textvariable=self.equation, width=16, font=('Times New Roman', 30, 'bold'))
        # entry.grid(row=0, column=0, columnspan=4)
        entry.place(relheight=0.2, relwidth=1, relx=0, rely=0)

        # 按钮
        buttons = [
            '7', '8', '9', '/',
            '4', '5', '6', '*',
            '1', '2', '3', '-',
            '0', '.', '=', '+'
        ]
        # 按键布局
        row, col = 1, 0
        for button in buttons:
            action = lambda x=button: self.on_button_click(x)
            calculator_button = Button(self, text=button, command=action)
            # calculator_button.grid(row=row, column=col)
            # 调整为place布局
            calculator_button.place(relheight=0.2, relwidth=0.25, relx=0.25 * col, rely=0.2 * row)

            col += 1
            if col > 3:
                col = 0
                row += 1

    def on_button_click(self, char):
        """结果计算"""
        if char == '=':
            try:
                result = str(eval(self.equation.get()))
                self.equation.set(result)
            except:
                self.equation.set("输入错误")
        else:
            current_text = self.equation.get()
            new_text = current_text + char
            self.equation.set(new_text)


if __name__ == "__main__":
    calculator = Calculator()
    calculator.mainloop()
```

![image-20240719113428699](/Tkinter%E5%BC%80%E5%8F%91%E8%AE%A1%E7%AE%97%E5%99%A8/image-20240719113428699.png)

## 计算器打包

这里需要用到第三方包 `PyInstaller`，`PyInstaller` 是一个将 `Python` 脚本转换为独立可执行文件的工具，适用于 `Windows`、`macOS` 和 `Linux`，使用如下命令行安装 `pyinstaller`

```python
pip install pyinstaller -i https://pypi.tuna.tsinghua.edu.cn/simple/
```

在终端中，`cd` 到 `tkinter` 脚本所在的目录，运行如下命令：

```shell
pyinstaller --onefile --windowed calculator.py
```

`PyInstaller ` 会在当前目录下生成一个 `dist` 文件夹，里面包含打包好的可执行文件。你可以在 `dist` 文件夹中找到名为 `calculator` 的可执行文件。

```
├─Button按钮组件
├─Calculator_计算器
│  ├─build
│  │  └─calculator
│  │      └─localpycs
│  └─dist
```

打包后，点击即可使用计算器。

![tkinter](/Tkinter%E5%BC%80%E5%8F%91%E8%AE%A1%E7%AE%97%E5%99%A8/tkinter.gif)