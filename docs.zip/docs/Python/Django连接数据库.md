---
title: Django使用连接串配置数据库
createTime: 2024/07/08 19:10:38
permalink: /article/django_database_config/
tags:
  - Python
  - Django
---

# `Django` 使用连接串配置数据库

## `Django` 配置数据库

修改 `settings.py` 中 `DATABASES`，这里以 `mysql` 数据库为例。

```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'your_database_name',
        'USER': 'your_database_user',
        'PASSWORD': 'your_database_password',
        'HOST': 'your_database_host',
        'PORT': 'your_database_port',
    }
}
```

配置完成后，依次执行如下语句，将数据库迁移至配置的 `mysql` 数据库。

```shell
python manage.py makemigrations
python manage.py migrate
```

## `Django Shell`

`Django shell` 是一个交互式的 `Python` 解释器，能够应用 `Django` 项目的模型以及环境变量。

更多信息可以查询 `Django` 官方文档：https://docs.djangoproject.com/en/5.0/ref/django-admin/#shell。

通过如下命令即可进入 `Django Shell`。

```shell
python manage.py shell
```

执行如下语句，即可使用配置的 `Mysql` 信息，执行相应的 `SQL` 语句。

```python
from django.db import connection

# 使用游标执行 SQL 查询
with connection.cursor() as cursor:
    cursor.execute("show tables")
    rows = cursor.fetchall()

# 打印结果
for row in rows:
    print(row)
```

输出结果为

```shell
(u'auth_group',)
(u'auth_group_permissions',)
(u'auth_permission',)
...
```

## `Django` 使用连接串配置数据库

`Django` 配置数据库为连接串，需要使用第三方库 `dj_database_url`，第三方库的文档地址：`https://github.com/jazzband/dj-database-url`。

配置 `Mysql` 的连接串格式为：

| `Engine` | `Django Backend`           | `URL`                                  |
| -------- | -------------------------- | -------------------------------------- |
| `MySQL`  | `django.db.backends.mysql` | `mysql://USER:PASSWORD@HOST:PORT/NAME` |

实际使用如下，这里的密码需要使用 `urllib` 库转化为 `URL` 编码，否则当密码中含有特殊字符 `#` 时会出现 `ValueError` 的报错。

```shell
# 实际的密码是：$#@!
ValueError: invalid literal for int() with base 10: '"euansu12356$'
```

`settings.py` 中做如下修改。

```python
# mysql://USER:PASSWORD@HOST:PORT/NAME
import dj_database_url
import urllib.parse

password = "password"
encoded_password = urllib.parse.quote_plus(password)

DATABASES = {
    'default': dj_database_url.parse(
        f'mysql://username:{encoded_password}@127.0.0.1:3306/database'
    )
}
```

再次使用 `django` 提供的 `connection` 工具，能够正常连接 `Mysql` 数据库并正常执行 `SQL`。

```python
from django.db import connection

# 使用游标执行 SQL 查询
with connection.cursor() as cursor:
    cursor.execute("show databases")
    rows = cursor.fetchall()

# 打印结果
for row in rows:
    print(row)
```

输出结果为

```shell
(u'information_schema',)
(u'560_amoro',)
(u'accept_5g',)
...
```

这里打印一下配置的数据库所有连接参数。

```python
# 配置的连接串为  `f'mysql://username:{encoded_password}@127.0.0.1:3306/database?ssl=Flase'`
from django.conf import settings
databases = settings.DATABASES
print(databases)
```

输出结果为

```shell
{'default': {'ENGINE': 'django.db.backends.mysql', 'ATOMIC_REQUESTS': False, 'CONN_MAX_AGE': 0, 'HOST': '127.0.0.1', 'USER': 'username', 'PASSWORD': 'password', 'OPTIONS': {'ssl': 'Flase'}, 'AUTOCOMMIT': True, 'NAME': 'database', 'TIME_ZONE': None, 'PORT': 3306, 'TEST': {'COLLATION': None, 'CHARSET': None, 'NAME': None, 'MIRROR': None}}}
```